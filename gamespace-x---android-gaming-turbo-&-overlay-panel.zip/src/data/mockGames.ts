import { GameItem } from '../types/gaming';

export const INITIAL_GAMES: GameItem[] = [
  {
    id: 'game-mlbb',
    name: 'Mobile Legends: Bang Bang',
    packageName: 'com.mobile.legends',
    bannerUrl: '/src/assets/images/game_moba_esports_1793430497389.jpg',
    category: 'MOBA 5v5',
    genre: 'Esports',
    targetFps: 120,
    performanceMode: 'beast',
    resolutionScale: 100,
    msaa4x: true,
    touchSamplingRate: 720,
    customDns: 'cloudflare_gaming',
    playtimeHours: 142.5,
    lastPlayed: 'Hari ini, 19:40'
  },
  {
    id: 'game-pubg',
    name: 'PUBG Mobile / BGMI',
    packageName: 'com.tencent.ig',
    bannerUrl: '/src/assets/images/game_tactical_shooter_1793430499645.jpg',
    category: 'Battle Royale',
    genre: 'Shooter',
    targetFps: 90,
    performanceMode: 'beast',
    resolutionScale: 100,
    msaa4x: true,
    touchSamplingRate: 1000,
    customDns: 'cloudflare_gaming',
    playtimeHours: 218.0,
    lastPlayed: 'Kemarin'
  },
  {
    id: 'game-genshin',
    name: 'Genshin Impact',
    packageName: 'com.miHoYo.GenshinImpact',
    bannerUrl: '/src/assets/images/game_fantasy_rpg_1793430500909.jpg',
    category: 'Open World RPG',
    genre: 'Adventure',
    targetFps: 60,
    performanceMode: 'beast',
    resolutionScale: 85,
    msaa4x: false,
    touchSamplingRate: 480,
    customDns: 'default',
    playtimeHours: 304.2,
    lastPlayed: '3 hari lalu'
  },
  {
    id: 'game-racing',
    name: 'CarX Street Racing',
    packageName: 'com.carxtech.sr',
    bannerUrl: '/src/assets/images/game_cyber_street_racing_1793430499610.jpg',
    category: 'Open World Racing',
    genre: 'Simulation',
    targetFps: 90,
    performanceMode: 'balanced',
    resolutionScale: 100,
    msaa4x: true,
    touchSamplingRate: 480,
    customDns: 'default',
    playtimeHours: 48.7,
    lastPlayed: '5 hari lalu'
  }
];
