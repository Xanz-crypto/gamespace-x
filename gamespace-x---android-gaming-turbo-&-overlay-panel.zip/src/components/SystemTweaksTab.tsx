import React, { useState } from 'react';
import {
  Cpu,
  Tv,
  Touchpad,
  Wifi,
  HardDrive,
  Layers,
  Zap,
  Sliders,
  CheckCircle2,
  RefreshCw,
  Terminal
} from 'lucide-react';
import { SystemTweakState, PrivilegeMode } from '../types/gaming';
import { soundManager } from '../utils/audio';

interface Props {
  tweaks: SystemTweakState;
  onUpdateTweaks: (tweaks: Partial<SystemTweakState>) => void;
  privilegeMode: PrivilegeMode;
  onAddLog: (command: string, source: 'root' | 'shizuku' | 'system', output?: string) => void;
}

export const SystemTweaksTab: React.FC<Props> = ({
  tweaks,
  onUpdateTweaks,
  privilegeMode,
  onAddLog
}) => {
  const [testingDns, setTestingDns] = useState(false);
  const [dnsResults, setDnsResults] = useState<{ [key: string]: number }>({
    cloudflare_gaming: 18,
    google: 28,
    quad9: 34,
    default: 45
  });

  const handleTestDns = () => {
    soundManager.playClick();
    setTestingDns(true);
    setTimeout(() => {
      setTestingDns(false);
      setDnsResults({
        cloudflare_gaming: Math.floor(14 + Math.random() * 8),
        google: Math.floor(22 + Math.random() * 10),
        quad9: Math.floor(28 + Math.random() * 10),
        default: Math.floor(38 + Math.random() * 15)
      });
      soundManager.playTurboBoost();
    }, 700);
  };

  const handleApplyResolution = (res: SystemTweakState['screenResolution']) => {
    soundManager.playClick();
    onUpdateTweaks({ screenResolution: res });
    const cmd =
      res === '720p'
        ? 'wm size 720x1600 && wm density 280'
        : res === '1080p'
        ? 'wm size 1080x2400 && wm density 420'
        : res === '2k'
        ? 'wm size 1440x3200 && wm density 560'
        : 'wm size reset && wm density reset';

    onAddLog(cmd, privilegeMode === 'root' ? 'root' : 'shizuku', `Resolution scaled to ${res.toUpperCase()}`);
  };

  return (
    <div className="space-y-6">
      {/* SECTION 1: CPU GOVERNOR & CLUSTERS */}
      <div className="rounded-2xl border border-white/10 bg-[#0a0e18]/80 p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              <Cpu className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">
                CPU Governor &amp; Frequency Scaling
              </h3>
              <p className="text-xs text-slate-400">
                Atur perilaku thread CPU big.LITTLE untuk mencegah frame drop
              </p>
            </div>
          </div>
          <span className="font-mono text-xs text-cyan-400 uppercase font-bold">
            {tweaks.governor}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {[
            {
              id: 'performance',
              name: 'Performance',
              desc: 'Kunci frekuensi maksimal tanpa throttling'
            },
            {
              id: 'schedutil',
              name: 'Schedutil (EAS)',
              desc: 'Peningkatan adaptif responsif hemat baterai'
            },
            {
              id: 'conservative',
              name: 'Conservative',
              desc: 'Peningkatan frekuensi bertahap stabil'
            },
            {
              id: 'powersave',
              name: 'Eco Gaming',
              desc: 'Batasi clock untuk temperatur dingin'
            }
          ].map((gov) => (
            <button
              key={gov.id}
              onClick={() => {
                soundManager.playClick();
                onUpdateTweaks({ governor: gov.id as any });
                onAddLog(
                  `for g in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do echo ${gov.id} > "$g"; done`,
                  privilegeMode === 'root' ? 'root' : 'shizuku',
                  `CPU governor locked to: ${gov.id}`
                );
              }}
              className={`p-3 rounded-xl border text-left transition ${
                tweaks.governor === gov.id
                  ? 'border-cyan-400 bg-cyan-950/30 shadow-md shadow-cyan-950/40 text-cyan-300'
                  : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
              }`}
            >
              <div className="text-xs font-bold">{gov.name}</div>
              <div className="text-[10px] opacity-75 mt-1 leading-snug">{gov.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* SECTION 2: RESOLUTION & RENDERING SCALE */}
      <div className="rounded-2xl border border-white/10 bg-[#0a0e18]/80 p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-pink-500/10 text-pink-400 border border-pink-500/30">
              <Tv className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">
                Render Resolution Scaler (ADB wm size)
              </h3>
              <p className="text-xs text-slate-400">
                Turunkan beban GPU pada game berat (Genshin, CarX) untuk FPS 90-120 stabil
              </p>
            </div>
          </div>
          <span className="font-mono text-xs text-pink-400 uppercase font-bold">
            {tweaks.screenResolution}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {[
            { id: '720p', label: '720p Esports (Boost +30 FPS)' },
            { id: '1080p', label: '1080p FHD (Seimbang)' },
            { id: '2k', label: '2K QHD (Grafis Ultra)' },
            { id: 'native', label: 'Reset Native Display' }
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => handleApplyResolution(item.id as any)}
              className={`p-3 rounded-xl border text-left transition ${
                tweaks.screenResolution === item.id
                  ? 'border-pink-400 bg-pink-950/30 text-pink-300 font-bold'
                  : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
              }`}
            >
              <span className="text-xs">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* SECTION 3: TOUCH ENGINE & POLLING RATE */}
      <div className="rounded-2xl border border-white/10 bg-[#0a0e18]/80 p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <Touchpad className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">
                Touch Sampling Polling Rate Tuner
              </h3>
              <p className="text-xs text-slate-400">
                Akurasi dan kecepatan input sentuhan layar untuk refleks cepat
              </p>
            </div>
          </div>
          <span className="font-mono text-xs text-emerald-400 font-bold">
            {tweaks.samplingRate} Hz
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {([240, 480, 720, 1000] as const).map((hz) => (
            <button
              key={hz}
              onClick={() => {
                soundManager.playClick();
                onUpdateTweaks({ samplingRate: hz });
                onAddLog(
                  `setprop persist.vendor.touch.sampling_rate ${hz}`,
                  privilegeMode === 'root' ? 'root' : 'shizuku',
                  `Touch report rate boosted to ${hz}Hz`
                );
              }}
              className={`p-3 rounded-xl border text-left transition ${
                tweaks.samplingRate === hz
                  ? 'border-emerald-400 bg-emerald-950/30 text-emerald-300 font-bold'
                  : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
              }`}
            >
              <div className="text-xs">{hz}Hz Ultra Polling</div>
              <div className="text-[10px] opacity-75 mt-0.5">
                Latency: {(1000 / hz).toFixed(2)}ms
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* SECTION 4: GAMING DNS ACCELERATOR */}
      <div className="rounded-2xl border border-white/10 bg-[#0a0e18]/80 p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              <Wifi className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">
                Gaming DNS Accelerator (Anti RTO &amp; Yellow Ping)
              </h3>
              <p className="text-xs text-slate-400">
                Rute server latensi rendah untuk mencegah packet loss saat ranked match
              </p>
            </div>
          </div>

          <button
            onClick={handleTestDns}
            disabled={testingDns}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono text-cyan-300 transition"
          >
            <RefreshCw className={`h-3 w-3 ${testingDns ? 'animate-spin' : ''}`} />
            <span>{testingDns ? 'Menguji...' : 'Tes Latensi Ping'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
          {[
            {
              id: 'cloudflare_gaming',
              name: 'Cloudflare 1.1.1.1 Gaming',
              ip: '1.1.1.1 / 1.0.0.1'
            },
            {
              id: 'google',
              name: 'Google Public DNS',
              ip: '8.8.8.8 / 8.8.4.4'
            },
            {
              id: 'quad9',
              name: 'Quad9 Low Latency',
              ip: '9.9.9.9'
            },
            {
              id: 'default',
              name: 'Provider ISP Bawaan',
              ip: 'DHCP Default'
            }
          ].map((item) => {
            const ping = dnsResults[item.id] || 30;
            return (
              <button
                key={item.id}
                onClick={() => {
                  soundManager.playClick();
                  onUpdateTweaks({ activeDns: item.id as any });
                  onAddLog(
                    `setprop net.dns1 ${item.ip.split(' ')[0]}`,
                    privilegeMode === 'root' ? 'root' : 'shizuku',
                    `Gaming DNS routed to: ${item.name}`
                  );
                }}
                className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                  tweaks.activeDns === item.id
                    ? 'border-cyan-400 bg-cyan-950/30 text-cyan-300 shadow-md'
                    : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
                }`}
              >
                <div>
                  <div className="text-xs font-bold">{item.name}</div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">{item.ip}</div>
                </div>
                <div className="mt-3 flex items-center justify-between font-mono text-xs">
                  <span className={ping < 25 ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                    ~{ping} ms
                  </span>
                  {tweaks.activeDns === item.id && (
                    <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-1.5 py-0.2 rounded font-sans">
                      Terpilih
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
