import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Zap,
  Crosshair,
  ShieldAlert,
  Flame,
  Volume2,
  Mic,
  Maximize2,
  Wifi,
  Cpu,
  Activity,
  Layers,
  Camera,
  Video,
  X,
  ChevronRight,
  Settings,
  BellOff,
  PhoneOff,
  Lock,
  SunMedium
} from 'lucide-react';
import {
  TelemetryData,
  CrosshairConfig,
  VoiceChangerPreset,
  SystemTweakState,
  PrivilegeMode,
  TerminalLog
} from '../types/gaming';
import { soundManager } from '../utils/audio';

interface Props {
  isOpen: boolean;
  onToggle: () => void;
  telemetry: TelemetryData;
  privilegeMode: PrivilegeMode;
  systemTweaks: SystemTweakState;
  onUpdateTweaks: (tweaks: Partial<SystemTweakState>) => void;
  crosshairConfig: CrosshairConfig;
  onUpdateCrosshair: (config: Partial<CrosshairConfig>) => void;
  onAddLog: (command: string, source: 'root' | 'shizuku' | 'system', output?: string) => void;
  gameTitle?: string;
  isCompact?: boolean;
}

export const InGameOverlayPanel: React.FC<Props> = ({
  isOpen,
  onToggle,
  telemetry,
  privilegeMode,
  systemTweaks,
  onUpdateTweaks,
  crosshairConfig,
  onUpdateCrosshair,
  onAddLog,
  gameTitle = 'Mobile Legends: Bang Bang',
  isCompact = false
}) => {
  const [activeTab, setActiveTab] = useState<'tools' | 'telemetry' | 'crosshair' | 'voice'>('tools');
  const [isBoosting, setIsBoosting] = useState(false);
  const [boostedAmount, setBoostedAmount] = useState<number | null>(null);
  const [recordingActive, setRecordingActive] = useState(false);
  const [screenshotFlash, setScreenshotFlash] = useState(false);
  const [voicePreset, setVoicePreset] = useState<VoiceChangerPreset>('off');
  const [dockSide, setDockSide] = useState<'left' | 'right'>('right');

  // Trigger 1-Tap RAM purge / Booster
  const handleBoostRam = () => {
    setIsBoosting(true);
    soundManager.playRamClean();

    // simulate freed RAM calculation
    const freedMb = Math.floor(650 + Math.random() * 450);

    setTimeout(() => {
      setIsBoosting(false);
      setBoostedAmount(freedMb);
      soundManager.playTurboBoost();

      try {
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#00F0FF', '#00FF9D', '#FF0055']
        });
      } catch {
        // confetti fallback
      }

      onAddLog(
        privilegeMode === 'root'
          ? 'echo 3 > /proc/sys/vm/drop_caches && am kill-all'
          : 'am kill-all && pm trim-caches 1073741824',
        privilegeMode === 'root' ? 'root' : 'shizuku',
        `Cleaned ${freedMb}MB cached background memory. Priority heap allocated to ${gameTitle}.`
      );

      setTimeout(() => setBoostedAmount(null), 4000);
    }, 800);
  };

  const handleToggleTweak = (key: keyof SystemTweakState, val: boolean, cmdDesc: string) => {
    soundManager.playToggle(!val);
    onUpdateTweaks({ [key]: val });
    onAddLog(
      `cmd appops set ${key} ${val ? 'ALLOW' : 'DENY'}`,
      privilegeMode === 'root' ? 'root' : 'shizuku',
      cmdDesc
    );
  };

  const handleTakeScreenshot = () => {
    soundManager.playClick();
    setScreenshotFlash(true);
    setTimeout(() => setScreenshotFlash(false), 300);
    onAddLog(
      'screencap -p /sdcard/Pictures/GameSpace/snap_' + Date.now() + '.png',
      privilegeMode === 'root' ? 'root' : 'shizuku',
      'Screenshot saved to Gallery'
    );
  };

  const handleToggleRecord = () => {
    soundManager.playToggle(!recordingActive);
    setRecordingActive(!recordingActive);
    onAddLog(
      recordingActive
        ? 'killall screenrecord'
        : 'screenrecord --bit-rate 24000000 --time-limit 1800 /sdcard/Movies/GameSpace/rec.mp4 &',
      privilegeMode === 'root' ? 'root' : 'shizuku',
      recordingActive ? 'Screen recording stopped' : 'Ultra 60FPS Game Recording started (24Mbps)'
    );
  };

  return (
    <>
      {/* Screen flash for screenshot */}
      {screenshotFlash && (
        <div className="pointer-events-none fixed inset-0 z-50 bg-white opacity-80 transition-opacity duration-300" />
      )}

      {/* FLOATING DOCKED TRIGGER PILL (When overlay is closed) */}
      {!isOpen && (
        <button
          onClick={() => {
            soundManager.playClick();
            onToggle();
          }}
          className={`fixed top-24 ${
            dockSide === 'right' ? 'right-0 rounded-l-2xl' : 'left-0 rounded-r-2xl'
          } z-40 flex items-center gap-2 border border-cyan-500/40 bg-[#090d16]/90 px-3 py-2.5 backdrop-blur-md shadow-lg shadow-cyan-950/50 hover:bg-[#0f172a] hover:border-cyan-400 active:scale-95 transition-all`}
          title="Buka Game Space Panel"
          aria-label="Open Game Space HUD"
        >
          <div className="flex items-center gap-1.5">
            <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <span className="font-mono text-xs font-bold text-cyan-400 tabular-nums">
              {Math.round(telemetry.fps)}
            </span>
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">FPS</span>
          </div>
          <ChevronRight className={`h-3.5 w-3.5 text-cyan-400 ${dockSide === 'left' ? 'rotate-180' : ''}`} />
        </button>
      )}

      {/* FULL IN-GAME HUD OVERLAY DOCK */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-md transition-all">
          <div className="relative w-full max-w-2xl overflow-hidden rounded-2xl border border-cyan-500/30 bg-[#080c14]/95 text-slate-200 shadow-2xl shadow-cyan-950/80">
            {/* Ambient top glow line */}
            <div className="h-1 w-full bg-gradient-to-r from-cyan-500 via-emerald-400 to-pink-500" />

            {/* Header / Game Title & Status */}
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-3.5 bg-[#0b101b]">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
                  <Zap className="h-4 w-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold tracking-tight text-white">{gameTitle}</span>
                    <span className="text-[10px] uppercase font-mono font-bold px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      {privilegeMode.toUpperCase()} MODE
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                    <span>Target: {telemetry.targetFps} FPS</span>
                    <span>·</span>
                    <span className="text-emerald-400">Jitter: {telemetry.jitterMs.toFixed(1)}ms</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setDockSide(dockSide === 'right' ? 'left' : 'right')}
                  className="rounded-lg p-2 text-slate-400 hover:text-white hover:bg-white/5 text-xs transition"
                  title="Pindah Sisi Dock"
                >
                  <Layers className="h-4 w-4" />
                </button>
                <button
                  onClick={() => {
                    soundManager.playClick();
                    onToggle();
                  }}
                  className="rounded-lg p-2 text-slate-400 hover:text-red-400 hover:bg-white/5 transition"
                  title="Tutup Panel"
                  aria-label="Close Panel"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            {/* REAL-TIME TELEMETRY BAR */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 p-3.5 border-b border-white/10 bg-[#060910]">
              {/* FPS Gauge */}
              <div className="rounded-xl border border-cyan-500/20 bg-cyan-950/20 p-2.5">
                <div className="text-[10px] font-mono uppercase text-cyan-400/80 flex items-center justify-between">
                  <span>Frame Rate</span>
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse" />
                </div>
                <div className="mt-1 flex items-baseline gap-1">
                  <span className="font-mono text-2xl font-black text-cyan-300 tabular-nums">
                    {Math.round(telemetry.fps)}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">/ {telemetry.targetFps}</span>
                </div>
                {/* Mini FPS sparkline */}
                <div className="mt-1 flex h-4 items-end gap-0.5 overflow-hidden">
                  {telemetry.frameHistory.slice(-16).map((val, idx) => {
                    const h = Math.min(100, Math.max(15, (val / telemetry.targetFps) * 100));
                    return (
                      <div
                        key={idx}
                        className={`w-1 rounded-xs transition-all ${
                          val < telemetry.targetFps * 0.8 ? 'bg-red-500' : 'bg-cyan-400'
                        }`}
                        style={{ height: `${h}%` }}
                      />
                    );
                  })}
                </div>
              </div>

              {/* CPU Metric */}
              <div className="rounded-xl border border-white/10 bg-slate-900/40 p-2.5">
                <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center gap-1">
                  <Cpu className="h-3 w-3 text-cyan-400" />
                  <span>CPU Load</span>
                </div>
                <div className="mt-1 font-mono text-xl font-bold text-slate-100 tabular-nums">
                  {Math.round(telemetry.cpuUsage)}%
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  {telemetry.cpuFreqGhz.toFixed(2)} GHz
                </div>
              </div>

              {/* GPU Metric */}
              <div className="rounded-xl border border-white/10 bg-slate-900/40 p-2.5">
                <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center gap-1">
                  <Activity className="h-3 w-3 text-emerald-400" />
                  <span>GPU Load</span>
                </div>
                <div className="mt-1 font-mono text-xl font-bold text-slate-100 tabular-nums">
                  {Math.round(telemetry.gpuUsage)}%
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  {telemetry.gpuFreqMhz} MHz
                </div>
              </div>

              {/* Thermal / Battery Temp */}
              <div className="rounded-xl border border-white/10 bg-slate-900/40 p-2.5">
                <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center gap-1">
                  <Flame className={`h-3 w-3 ${telemetry.cpuTempC > 42 ? 'text-red-400' : 'text-amber-400'}`} />
                  <span>Suhu Temp</span>
                </div>
                <div className="mt-1 font-mono text-xl font-bold text-slate-100 tabular-nums">
                  {telemetry.cpuTempC.toFixed(1)}°C
                </div>
                <div className={`text-[10px] font-mono ${telemetry.cpuTempC > 42 ? 'text-red-400 font-semibold' : 'text-emerald-400'}`}>
                  {telemetry.cpuTempC > 42 ? 'Thermal Warm' : 'Optimal Chill'}
                </div>
              </div>

              {/* Ping / Latency */}
              <div className="rounded-xl border border-white/10 bg-slate-900/40 p-2.5 col-span-2 sm:col-span-1">
                <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center gap-1">
                  <Wifi className="h-3 w-3 text-cyan-400" />
                  <span>Latency Ping</span>
                </div>
                <div className="mt-1 flex items-baseline gap-1">
                  <span className={`font-mono text-xl font-bold tabular-nums ${telemetry.pingMs < 40 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {Math.round(telemetry.pingMs)}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">ms</span>
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  Loss: {telemetry.packetLoss.toFixed(1)}%
                </div>
              </div>
            </div>

            {/* TAB SELECTOR */}
            <div className="flex border-b border-white/10 bg-[#090e18] px-4 pt-2">
              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveTab('tools');
                }}
                className={`px-4 py-2 text-xs font-semibold tracking-wide transition border-b-2 ${
                  activeTab === 'tools'
                    ? 'border-cyan-400 text-cyan-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Quick Tools
              </button>
              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveTab('crosshair');
                }}
                className={`px-4 py-2 text-xs font-semibold tracking-wide transition border-b-2 ${
                  activeTab === 'crosshair'
                    ? 'border-cyan-400 text-cyan-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Tactical Crosshair
              </button>
              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveTab('voice');
                }}
                className={`px-4 py-2 text-xs font-semibold tracking-wide transition border-b-2 ${
                  activeTab === 'voice'
                    ? 'border-cyan-400 text-cyan-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Voice FX
              </button>
            </div>

            {/* TAB CONTENTS */}
            <div className="p-4 sm:p-5 max-h-[55vh] overflow-y-auto">
              {/* TAB 1: QUICK TOOLS */}
              {activeTab === 'tools' && (
                <div className="space-y-4">
                  {/* Primary 1-Tap RAM Booster Banner */}
                  <div className="relative overflow-hidden rounded-xl border border-cyan-500/40 bg-gradient-to-r from-cyan-950/40 via-slate-900 to-indigo-950/40 p-4">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-white">Aggressive RAM Purge &amp; Priority Heap</span>
                          {boostedAmount && (
                            <span className="text-xs font-mono font-bold text-emerald-400">
                              +{boostedAmount}MB Freed!
                            </span>
                          )}
                        </div>
                        <p className="mt-0.5 text-xs text-slate-300">
                          Used: {telemetry.ramUsedGb.toFixed(1)} GB / {telemetry.ramTotalGb} GB · Kills background bloatware via Shizuku
                        </p>
                      </div>

                      <button
                        onClick={handleBoostRam}
                        disabled={isBoosting}
                        className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-95 transition disabled:opacity-50"
                      >
                        <Zap className={`h-4 w-4 ${isBoosting ? 'animate-spin' : ''}`} />
                        {isBoosting ? 'Purging Cache...' : '1-Tap Boost RAM'}
                      </button>
                    </div>
                  </div>

                  {/* Quick Toggles Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {/* DND Notifications */}
                    <button
                      onClick={() =>
                        handleToggleTweak(
                          'dndNotifications',
                          !systemTweaks.dndNotifications,
                          systemTweaks.dndNotifications ? 'DND Notifications disabled' : 'Block all heads-up notifications active'
                        )
                      }
                      className={`flex flex-col items-start p-3 rounded-xl border text-left transition ${
                        systemTweaks.dndNotifications
                          ? 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300'
                          : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
                      }`}
                    >
                      <BellOff className="h-4 w-4 mb-2" />
                      <span className="text-xs font-semibold">Block Notif</span>
                      <span className="text-[10px] opacity-75 mt-0.5">
                        {systemTweaks.dndNotifications ? 'Aktif' : 'Mati'}
                      </span>
                    </button>

                    {/* DND Calls */}
                    <button
                      onClick={() =>
                        handleToggleTweak(
                          'dndCalls',
                          !systemTweaks.dndCalls,
                          systemTweaks.dndCalls ? 'Call rejection disabled' : 'Auto reject incoming calls active'
                        )
                      }
                      className={`flex flex-col items-start p-3 rounded-xl border text-left transition ${
                        systemTweaks.dndCalls
                          ? 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300'
                          : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
                      }`}
                    >
                      <PhoneOff className="h-4 w-4 mb-2" />
                      <span className="text-xs font-semibold">Tolak Panggilan</span>
                      <span className="text-[10px] opacity-75 mt-0.5">
                        {systemTweaks.dndCalls ? 'Auto Reject' : 'Standar'}
                      </span>
                    </button>

                    {/* Lock Gestures */}
                    <button
                      onClick={() =>
                        handleToggleTweak(
                          'lockGestures',
                          !systemTweaks.lockGestures,
                          systemTweaks.lockGestures ? 'Nav gestures unlocked' : 'Anti mistouch gesture locked'
                        )
                      }
                      className={`flex flex-col items-start p-3 rounded-xl border text-left transition ${
                        systemTweaks.lockGestures
                          ? 'border-cyan-500/40 bg-cyan-950/20 text-cyan-300'
                          : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
                      }`}
                    >
                      <Lock className="h-4 w-4 mb-2" />
                      <span className="text-xs font-semibold">Kunci Navigasi</span>
                      <span className="text-[10px] opacity-75 mt-0.5">
                        {systemTweaks.lockGestures ? 'Anti-Mistouch' : 'Bebas'}
                      </span>
                    </button>

                    {/* Thermal Bypass */}
                    <button
                      onClick={() =>
                        handleToggleTweak(
                          'bypassThermal',
                          !systemTweaks.bypassThermal,
                          systemTweaks.bypassThermal ? 'Thermal limit restored' : 'Thermal throttling override forced'
                        )
                      }
                      className={`flex flex-col items-start p-3 rounded-xl border text-left transition ${
                        systemTweaks.bypassThermal
                          ? 'border-pink-500/40 bg-pink-950/20 text-pink-300'
                          : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
                      }`}
                    >
                      <Flame className="h-4 w-4 mb-2" />
                      <span className="text-xs font-semibold">Thermal Bypass</span>
                      <span className="text-[10px] opacity-75 mt-0.5">
                        {systemTweaks.bypassThermal ? 'No Throttling' : 'Normal'}
                      </span>
                    </button>

                    {/* 1000Hz Touch Sampling Boost */}
                    <button
                      onClick={() =>
                        handleToggleTweak(
                          'touchSamplingBoost',
                          !systemTweaks.touchSamplingBoost,
                          systemTweaks.touchSamplingBoost ? 'Touch 480Hz' : 'Touch 1000Hz Ultra Polling forced'
                        )
                      }
                      className={`flex flex-col items-start p-3 rounded-xl border text-left transition ${
                        systemTweaks.touchSamplingBoost
                          ? 'border-cyan-500/40 bg-cyan-950/20 text-cyan-300'
                          : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
                      }`}
                    >
                      <Zap className="h-4 w-4 mb-2 text-cyan-400" />
                      <span className="text-xs font-semibold">1000Hz Touch</span>
                      <span className="text-[10px] opacity-75 mt-0.5">
                        {systemTweaks.touchSamplingBoost ? '1000Hz Ultra' : '480Hz'}
                      </span>
                    </button>

                    {/* Direct Battery Bypass */}
                    <button
                      onClick={() =>
                        handleToggleTweak(
                          'bypassCharging',
                          !systemTweaks.bypassCharging,
                          systemTweaks.bypassCharging ? 'Standard charging restored' : 'Direct power bypass active (reduces battery heat)'
                        )
                      }
                      className={`flex flex-col items-start p-3 rounded-xl border text-left transition ${
                        systemTweaks.bypassCharging
                          ? 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300'
                          : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
                      }`}
                    >
                      <ShieldAlert className="h-4 w-4 mb-2 text-emerald-400" />
                      <span className="text-xs font-semibold">Bypass Charge</span>
                      <span className="text-[10px] opacity-75 mt-0.5">
                        {systemTweaks.bypassCharging ? 'Direct Power' : 'Standar'}
                      </span>
                    </button>

                    {/* Quick Screenshot */}
                    <button
                      onClick={handleTakeScreenshot}
                      className="flex flex-col items-start p-3 rounded-xl border border-white/10 bg-slate-900/40 text-slate-300 hover:border-cyan-500/40 hover:bg-slate-800/60 text-left transition"
                    >
                      <Camera className="h-4 w-4 mb-2 text-cyan-400" />
                      <span className="text-xs font-semibold">Screenshot</span>
                      <span className="text-[10px] opacity-75 mt-0.5">Instant Snap</span>
                    </button>

                    {/* Screen Recorder */}
                    <button
                      onClick={handleToggleRecord}
                      className={`flex flex-col items-start p-3 rounded-xl border text-left transition ${
                        recordingActive
                          ? 'border-red-500/40 bg-red-950/20 text-red-300 animate-pulse'
                          : 'border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/20'
                      }`}
                    >
                      <Video className="h-4 w-4 mb-2" />
                      <span className="text-xs font-semibold">Screen Record</span>
                      <span className="text-[10px] opacity-75 mt-0.5">
                        {recordingActive ? 'Merekam 60FPS' : 'Mulai Rekam'}
                      </span>
                    </button>
                  </div>

                  {/* GPU Renderer & Display Refresh Rate Selectors */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="rounded-xl border border-white/10 bg-slate-900/30 p-3">
                      <div className="text-xs font-semibold text-slate-300 mb-2 flex items-center justify-between">
                        <span>GPU Graphics Backend</span>
                        <span className="text-[10px] font-mono text-cyan-400 uppercase">{systemTweaks.gpuRenderer}</span>
                      </div>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(['vulkan', 'skiavk', 'opengl'] as const).map((mode) => (
                          <button
                            key={mode}
                            onClick={() => {
                              soundManager.playClick();
                              onUpdateTweaks({ gpuRenderer: mode });
                              onAddLog(
                                `setprop debug.hwui.renderer ${mode === 'opengl' ? 'opengl' : 'skiavk'}`,
                                privilegeMode === 'root' ? 'root' : 'shizuku',
                                `Graphics pipeline switched to ${mode.toUpperCase()}`
                              );
                            }}
                            className={`px-2 py-1.5 rounded-lg text-xs font-mono font-medium transition ${
                              systemTweaks.gpuRenderer === mode
                                ? 'bg-cyan-500 text-slate-950 font-bold'
                                : 'bg-slate-800/60 text-slate-300 hover:bg-slate-700/60'
                            }`}
                          >
                            {mode.toUpperCase()}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="rounded-xl border border-white/10 bg-slate-900/30 p-3">
                      <div className="text-xs font-semibold text-slate-300 mb-2 flex items-center justify-between">
                        <span>Lock Refresh Rate</span>
                        <span className="text-[10px] font-mono text-emerald-400">{systemTweaks.refreshRate} Hz</span>
                      </div>
                      <div className="grid grid-cols-4 gap-1.5">
                        {([60, 90, 120, 144] as const).map((hz) => (
                          <button
                            key={hz}
                            onClick={() => {
                              soundManager.playClick();
                              onUpdateTweaks({ refreshRate: hz });
                              onAddLog(
                                `settings put system peak_refresh_rate ${hz}.0 && settings put system min_refresh_rate ${hz}.0`,
                                privilegeMode === 'root' ? 'root' : 'shizuku',
                                `Display locked to ${hz}Hz`
                              );
                            }}
                            className={`px-2 py-1.5 rounded-lg text-xs font-mono font-medium transition ${
                              systemTweaks.refreshRate === hz
                                ? 'bg-emerald-500 text-slate-950 font-bold'
                                : 'bg-slate-800/60 text-slate-300 hover:bg-slate-700/60'
                            }`}
                          >
                            {hz}Hz
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: TACTICAL CROSSHAIR */}
              {activeTab === 'crosshair' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between rounded-xl border border-white/10 bg-slate-900/40 p-3.5">
                    <div>
                      <div className="text-sm font-bold text-white flex items-center gap-2">
                        <Crosshair className="h-4 w-4 text-cyan-400" />
                        <span>Overlay Crosshair / Reticle</span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Tampilkan bidikan presisi di tengah layar untuk game battle royale &amp; FPS
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        soundManager.playToggle(!crosshairConfig.enabled);
                        onUpdateCrosshair({ enabled: !crosshairConfig.enabled });
                      }}
                      className={`px-4 py-2 rounded-lg text-xs font-bold transition ${
                        crosshairConfig.enabled
                          ? 'bg-cyan-500 text-slate-950'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {crosshairConfig.enabled ? 'Aktif' : 'Mati'}
                    </button>
                  </div>

                  {/* Crosshair Styles */}
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {[
                      { id: 'red_dot', name: 'Red Dot' },
                      { id: 'classic_cross', name: 'Classic Cross' },
                      { id: 'tactical_circle', name: 'Circle Dot' },
                      { id: 'chevron', name: 'Chevron V' },
                      { id: 'cyber_reticle', name: 'Cyberpunk' }
                    ].map((item) => (
                      <button
                        key={item.id}
                        onClick={() => {
                          soundManager.playClick();
                          onUpdateCrosshair({ style: item.id as any, enabled: true });
                        }}
                        className={`p-3 rounded-xl border text-center transition flex flex-col items-center justify-center gap-2 ${
                          crosshairConfig.style === item.id
                            ? 'border-cyan-400 bg-cyan-950/20 text-cyan-300'
                            : 'border-white/10 bg-slate-900/30 text-slate-300 hover:bg-slate-800/40'
                        }`}
                      >
                        <div className="h-7 flex items-center justify-center">
                          <Crosshair className="h-5 w-5 text-current" />
                        </div>
                        <span className="text-xs font-medium">{item.name}</span>
                      </button>
                    ))}
                  </div>

                  {/* Color & Size Adjusters */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="rounded-xl border border-white/10 bg-slate-900/30 p-3">
                      <div className="text-xs font-semibold text-slate-300 mb-2">Warna Reticle</div>
                      <div className="flex items-center gap-2">
                        {['#00F0FF', '#FF0055', '#00FF9D', '#FFB703', '#FFFFFF'].map((c) => (
                          <button
                            key={c}
                            onClick={() => onUpdateCrosshair({ color: c })}
                            className={`h-7 w-7 rounded-full border-2 transition ${
                              crosshairConfig.color === c ? 'border-white scale-110' : 'border-transparent'
                            }`}
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </div>
                    </div>

                    <div className="rounded-xl border border-white/10 bg-slate-900/30 p-3">
                      <div className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-1">
                        <span>Ukuran Reticle</span>
                        <span className="font-mono text-cyan-400">{crosshairConfig.size}px</span>
                      </div>
                      <input
                        type="range"
                        min="12"
                        max="48"
                        value={crosshairConfig.size}
                        onChange={(e) => onUpdateCrosshair({ size: Number(e.target.value) })}
                        className="w-full accent-cyan-400"
                      />
                    </div>
                  </div>

                  {/* Touch Position Calibration & Lock Controls */}
                  <div className="rounded-xl border border-cyan-500/30 bg-cyan-950/20 p-3.5 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span>Kalibrasi Posisi Sentuh (Touch Drag)</span>
                      </div>
                      <span className="font-mono text-[11px] text-cyan-300">
                        X: {Math.round(crosshairConfig.position?.x ?? 50)}% · Y: {Math.round(crosshairConfig.position?.y ?? 50)}%
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-300">
                      Anda dapat menyentuh dan menggeser crosshair secara langsung di atas layar game simulator untuk menyesuaikan titik tembak hipfire / iron sight.
                    </p>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => {
                          soundManager.playClick();
                          onUpdateCrosshair({ position: { x: 50, y: 50 } });
                        }}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono text-cyan-300 border border-white/10 transition"
                      >
                        Reset ke Tengah (50%, 50%)
                      </button>

                      <button
                        onClick={() => {
                          soundManager.playToggle(!crosshairConfig.isLocked);
                          onUpdateCrosshair({ isLocked: !crosshairConfig.isLocked });
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-mono border transition ${
                          crosshairConfig.isLocked
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : 'bg-slate-800 text-slate-300 border-white/10 hover:bg-slate-700'
                        }`}
                      >
                        {crosshairConfig.isLocked ? '🔒 Posisi Terkunci' : '🔓 Buka Geser Sentuh'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: VOICE CHANGER SIMULATION */}
              {activeTab === 'voice' && (
                <div className="space-y-4">
                  <div className="rounded-xl border border-white/10 bg-slate-900/40 p-3.5">
                    <div className="flex items-center gap-2 text-sm font-bold text-white">
                      <Mic className="h-4 w-4 text-cyan-400" />
                      <span>In-Game Voice Changer &amp; Mic Effects</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      Ubah suara mikrofon in-game Anda secara langsung (Discord, MLBB squad voice, PUBG squad chat).
                    </p>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {[
                      { id: 'off', label: 'Suara Asli' },
                      { id: 'deep_titan', label: 'Titan Bass' },
                      { id: 'cyber_cyborg', label: 'Cyborg Robot' },
                      { id: 'alien_chipmunk', label: 'Alien Chipmunk' },
                      { id: 'tactical_radio', label: 'Radio Walkie' }
                    ].map((item) => (
                      <button
                        key={item.id}
                        onClick={() => {
                          soundManager.playClick();
                          setVoicePreset(item.id as VoiceChangerPreset);
                          onAddLog(
                            `setprop audio.mic.dsp.preset ${item.id}`,
                            privilegeMode === 'root' ? 'root' : 'shizuku',
                            `Voice changer switched to: ${item.label}`
                          );
                        }}
                        className={`p-3 rounded-xl border text-center transition flex flex-col items-center justify-center gap-1.5 ${
                          voicePreset === item.id
                            ? 'border-emerald-400 bg-emerald-950/20 text-emerald-300 font-bold'
                            : 'border-white/10 bg-slate-900/30 text-slate-300 hover:bg-slate-800/40'
                        }`}
                      >
                        <Volume2 className="h-4 w-4 text-current" />
                        <span className="text-xs">{item.label}</span>
                      </button>
                    ))}
                  </div>

                  <div className="rounded-xl border border-cyan-500/20 bg-cyan-950/10 p-3 text-xs text-slate-300 flex items-center justify-between">
                    <span>Status DSP Mic Filter:</span>
                    <span className="font-mono text-cyan-300 uppercase font-semibold">
                      {voicePreset === 'off' ? 'Bypass (Normal)' : 'Active DSP Intercept'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Status Ticker */}
            <div className="border-t border-white/10 bg-[#070b13] px-5 py-2.5 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <div className="flex items-center gap-3">
                <span>Kernel: 5.15-perf-schedutil</span>
                <span>·</span>
                <span>Governor: {systemTweaks.governor}</span>
              </div>
              <div className="text-cyan-400">
                Shizuku Binder: <span className="text-emerald-400 font-bold">CONNECTED</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
