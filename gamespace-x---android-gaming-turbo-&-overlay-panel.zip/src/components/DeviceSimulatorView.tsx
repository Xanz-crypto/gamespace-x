import React, { useState, useRef } from 'react';
import { GameItem, TelemetryData, SystemTweakState, PrivilegeMode, CrosshairConfig } from '../types/gaming';
import { InGameOverlayPanel } from './InGameOverlayPanel';
import { FloatingCrosshairWidget } from './FloatingCrosshairWidget';
import { soundManager } from '../utils/audio';
import { ArrowLeft, Crosshair, Sparkles, Smartphone, Terminal, Volume2, VolumeX, Eye } from 'lucide-react';

interface Props {
  game: GameItem;
  onExit: () => void;
  telemetry: TelemetryData;
  privilegeMode: PrivilegeMode;
  systemTweaks: SystemTweakState;
  onUpdateTweaks: (tweaks: Partial<SystemTweakState>) => void;
  crosshairConfig: CrosshairConfig;
  onUpdateCrosshair: (config: Partial<CrosshairConfig>) => void;
  onAddLog: (command: string, source: 'root' | 'shizuku' | 'system', output?: string) => void;
}

export const DeviceSimulatorView: React.FC<Props> = ({
  game,
  onExit,
  telemetry,
  privilegeMode,
  systemTweaks,
  onUpdateTweaks,
  crosshairConfig,
  onUpdateCrosshair,
  onAddLog
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isOverlayOpen, setIsOverlayOpen] = useState(false);
  const [simulatedScore, setSimulatedScore] = useState(14);
  const [joystickPos, setJoystickPos] = useState({ x: 0, y: 0 });
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const triggerActionFeedback = (text: string) => {
    soundManager.playClick();
    setActionFeedback(text);
    setTimeout(() => setActionFeedback(null), 1200);
  };

  return (
    <div className="relative min-h-[85vh] w-full flex flex-col items-center justify-center bg-black p-2 sm:p-4 select-none">
      {/* Top Simulator Control Bar */}
      <div className="w-full max-w-5xl flex items-center justify-between pb-3 text-xs text-slate-400">
        <button
          onClick={() => {
            soundManager.playClick();
            onExit();
          }}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-slate-200 hover:text-white hover:border-cyan-400 transition"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Kembali ke Game Space Hub</span>
        </button>

        <div className="flex items-center gap-2 sm:gap-3">
          <div className="hidden lg:flex items-center gap-2 text-[11px] font-mono text-cyan-400">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Session: {game.name}</span>
          </div>

          {/* Global Crosshair Quick Toggle Button */}
          <button
            onClick={() => {
              soundManager.playToggle(!crosshairConfig.enabled);
              onUpdateCrosshair({ enabled: !crosshairConfig.enabled });
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition ${
              crosshairConfig.enabled
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/60 shadow-sm'
                : 'bg-slate-900 border-white/10 text-slate-400 hover:text-white'
            }`}
            title="Toggle Floating Crosshair"
          >
            <Crosshair className="h-3.5 w-3.5 text-cyan-400" />
            <span>Crosshair: {crosshairConfig.enabled ? 'ON' : 'OFF'}</span>
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              setIsOverlayOpen(!isOverlayOpen);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold hover:bg-cyan-500/30 transition"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>{isOverlayOpen ? 'Tutup Panel' : 'Game Space HUD'}</span>
          </button>
        </div>
      </div>

      {/* SMARTPHONE FRAME CONTAINER (Landscape 20:9 Aspect Ratio) */}
      <div
        ref={containerRef}
        className="relative w-full max-w-5xl aspect-[19.5/9] max-h-[78vh] rounded-3xl overflow-hidden border-4 border-slate-800 bg-[#06080e] shadow-2xl shadow-cyan-950/40"
      >
        {/* Android Punch-hole Camera Notch */}
        <div className="absolute top-1/2 left-3 -translate-y-1/2 z-30 h-4 w-4 rounded-full bg-black border border-white/10" />

        {/* Game Background Gameplay Graphic */}
        <div className="absolute inset-0 z-0">
          <img
            src={game.bannerUrl}
            alt={game.name}
            className="h-full w-full object-cover brightness-[0.75] contrast-[1.1]"
            referrerPolicy="no-referrer"
          />
          {/* Subtle vignette scrim */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />
        </div>

        {/* NEW FLOATING CROSSHAIR WIDGET (Remains visible on top of content, touch movable, globally toggleable) */}
        <FloatingCrosshairWidget
          config={crosshairConfig}
          onUpdateConfig={onUpdateCrosshair}
          containerRef={containerRef}
          onAddLog={onAddLog}
        />

        {/* IN-GAME FLOATING HUD OVERLAY / DOCK PILL */}
        <InGameOverlayPanel
          isOpen={isOverlayOpen}
          onToggle={() => setIsOverlayOpen(!isOverlayOpen)}
          telemetry={telemetry}
          privilegeMode={privilegeMode}
          systemTweaks={systemTweaks}
          onUpdateTweaks={onUpdateTweaks}
          crosshairConfig={crosshairConfig}
          onUpdateCrosshair={onUpdateCrosshair}
          onAddLog={onAddLog}
          gameTitle={game.name}
        />

        {/* SIMULATED IN-GAME HUD UI (Score, skills, minimap, touch buttons) */}
        <div className="relative z-10 h-full w-full flex flex-col justify-between p-4 sm:p-6 pointer-events-auto">
          {/* In-game Top Stats Bar */}
          <div className="flex items-center justify-between text-white drop-shadow-md">
            {/* Left: Mini-map simulator */}
            <div className="flex items-center gap-3">
              <div className="relative h-14 w-14 rounded-full border-2 border-cyan-400/60 bg-black/60 overflow-hidden backdrop-blur-xs flex items-center justify-center">
                <div className="absolute inset-0 cyber-grid opacity-30" />
                <div className="radar-sweep absolute inset-0" />
                <div className="h-2 w-2 rounded-full bg-cyan-400" />
                <div className="absolute top-2 right-3 h-1.5 w-1.5 rounded-full bg-red-500 animate-pulse" />
              </div>
              <div className="text-left font-mono">
                <div className="text-xs font-black tracking-wide text-cyan-300">MATCH #3942</div>
                <div className="text-[10px] text-slate-300">K/D/A: {simulatedScore} / 2 / 8</div>
              </div>
            </div>

            {/* Middle: Game Banner / Timer */}
            <div className="rounded-lg bg-black/60 border border-white/10 px-3 py-1 font-mono text-xs font-bold text-amber-300 backdrop-blur-xs">
              08:42
            </div>

            {/* Right: Quick Ping & Battery */}
            <div className="flex items-center gap-3 font-mono text-xs">
              <div className="flex items-center gap-1 text-emerald-400 bg-black/60 px-2 py-1 rounded border border-white/10">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                <span>{Math.round(telemetry.pingMs)}ms</span>
              </div>
              <div className="text-slate-300 bg-black/60 px-2 py-1 rounded border border-white/10">
                {telemetry.batteryPct}%
              </div>
            </div>
          </div>

          {/* Action Feedback Banner */}
          {actionFeedback && (
            <div className="self-center px-4 py-1.5 rounded-full bg-cyan-500/90 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-lg animate-bounce">
              {actionFeedback}
            </div>
          )}

          {/* Bottom Controls / Virtual Gamepad Buttons */}
          <div className="flex items-end justify-between">
            {/* Left: Virtual D-Pad / Movement Stick */}
            <div
              className="relative h-28 w-28 rounded-full border-2 border-white/20 bg-black/40 backdrop-blur-xs flex items-center justify-center cursor-pointer active:scale-95 transition"
              onClick={() => triggerActionFeedback('Hero Moving...')}
            >
              <div className="h-12 w-12 rounded-full bg-cyan-500/50 border border-cyan-300 flex items-center justify-center text-[10px] font-bold text-white shadow-lg">
                MOVE
              </div>
            </div>

            {/* Right: Combat Buttons (Skill 1, Skill 2, Ultimate, Basic Attack) */}
            <div className="relative flex items-center gap-3">
              <button
                onClick={() => {
                  triggerActionFeedback('Skill 1 Fired!');
                  setSimulatedScore((s) => s + 1);
                }}
                className="h-12 w-12 rounded-full border border-cyan-400/80 bg-cyan-950/70 text-cyan-200 font-bold text-xs flex items-center justify-center hover:bg-cyan-900 active:scale-90 transition shadow-lg"
              >
                S1
              </button>

              <button
                onClick={() => {
                  triggerActionFeedback('Skill 2 Stun!');
                  setSimulatedScore((s) => s + 1);
                }}
                className="h-12 w-12 rounded-full border border-emerald-400/80 bg-emerald-950/70 text-emerald-200 font-bold text-xs flex items-center justify-center hover:bg-emerald-900 active:scale-90 transition shadow-lg"
              >
                S2
              </button>

              <button
                onClick={() => {
                  triggerActionFeedback('ULTIMATE COMBO!');
                  setSimulatedScore((s) => s + 2);
                  soundManager.playTurboBoost();
                }}
                className="h-14 w-14 rounded-full border-2 border-pink-500 bg-pink-950/80 text-pink-200 font-black text-xs flex items-center justify-center hover:bg-pink-900 active:scale-90 transition shadow-lg shadow-pink-500/30"
              >
                ULT
              </button>

              <button
                onClick={() => {
                  triggerActionFeedback('Basic Attack');
                }}
                className="h-16 w-16 rounded-full border-2 border-amber-400 bg-amber-950/80 text-amber-100 font-black text-xs flex items-center justify-center hover:bg-amber-900 active:scale-90 transition shadow-lg"
              >
                ATTACK
              </button>
            </div>
          </div>
        </div>

        {/* Watermark Tip */}
        <div className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 text-[10px] font-mono text-slate-400/80 bg-black/60 px-3 py-0.5 rounded-full">
          Geser atau klik pill cyan di tepi layar untuk memanggil Game Space HUD Overlay
        </div>
      </div>
    </div>
  );
};
