import React from 'react';
import { CrosshairConfig } from '../types/gaming';

interface Props {
  config: CrosshairConfig;
}

export const CrosshairOverlay: React.FC<Props> = ({ config }) => {
  if (!config.enabled) return null;

  const { style, color, size, thickness, opacity } = config;
  const halfSize = size / 2;

  return (
    <div
      className="pointer-events-none absolute inset-0 z-40 flex items-center justify-center transition-all"
      style={{ opacity }}
    >
      {style === 'red_dot' && (
        <div
          className="rounded-full shadow-sm"
          style={{
            width: `${size / 3}px`,
            height: `${size / 3}px`,
            backgroundColor: color,
            boxShadow: `0 0 10px ${color}`
          }}
        />
      )}

      {style === 'classic_cross' && (
        <div className="relative flex items-center justify-center" style={{ width: `${size}px`, height: `${size}px` }}>
          {/* Horizontal */}
          <div
            className="absolute rounded-full"
            style={{
              width: `${size}px`,
              height: `${thickness}px`,
              backgroundColor: color,
              boxShadow: `0 0 6px ${color}`
            }}
          />
          {/* Vertical */}
          <div
            className="absolute rounded-full"
            style={{
              height: `${size}px`,
              width: `${thickness}px`,
              backgroundColor: color,
              boxShadow: `0 0 6px ${color}`
            }}
          />
          {/* Center gap dot */}
          <div
            className="absolute rounded-full"
            style={{
              width: `${thickness + 1}px`,
              height: `${thickness + 1}px`,
              backgroundColor: color
            }}
          />
        </div>
      )}

      {style === 'tactical_circle' && (
        <div
          className="relative flex items-center justify-center rounded-full"
          style={{
            width: `${size}px`,
            height: `${size}px`,
            border: `${thickness}px solid ${color}`,
            boxShadow: `0 0 8px ${color}`
          }}
        >
          <div
            className="rounded-full"
            style={{
              width: `${thickness * 2}px`,
              height: `${thickness * 2}px`,
              backgroundColor: color
            }}
          />
        </div>
      )}

      {style === 'chevron' && (
        <svg
          width={size}
          height={size}
          viewBox="0 0 32 32"
          fill="none"
          className="drop-shadow-md"
          style={{ filter: `drop-shadow(0 0 4px ${color})` }}
        >
          <path
            d="M8 20L16 10L24 20"
            stroke={color}
            strokeWidth={thickness}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="16" cy="16" r={thickness / 1.5} fill={color} />
        </svg>
      )}

      {style === 'cyber_reticle' && (
        <svg
          width={size}
          height={size}
          viewBox="0 0 40 40"
          fill="none"
          style={{ filter: `drop-shadow(0 0 5px ${color})` }}
        >
          {/* Outer angled brackets */}
          <path d="M10 6H6V10" stroke={color} strokeWidth={thickness} strokeLinecap="round" />
          <path d="M30 6H34V10" stroke={color} strokeWidth={thickness} strokeLinecap="round" />
          <path d="M10 34H6V30" stroke={color} strokeWidth={thickness} strokeLinecap="round" />
          <path d="M30 34H34V30" stroke={color} strokeWidth={thickness} strokeLinecap="round" />
          {/* Center dot */}
          <circle cx="20" cy="20" r={thickness} fill={color} />
        </svg>
      )}
    </div>
  );
};
