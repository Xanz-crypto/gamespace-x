import React, { useState, useEffect } from 'react';
import {
  Download,
  Smartphone,
  Terminal,
  FolderArchive,
  Check,
  Copy,
  FileCode,
  ShieldAlert,
  X,
  Sparkles
} from 'lucide-react';
import { generateShizukuScript, generateMagiskModuleScript } from '../utils/shizukuCommands';
import { SystemTweakState } from '../types/gaming';
import { soundManager } from '../utils/audio';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  systemTweaks: SystemTweakState;
}

export const ApkExportModal: React.FC<Props> = ({ isOpen, onClose, systemTweaks }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  useEffect(() => {
    const handleBeforePrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handleBeforePrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforePrompt);
  }, []);

  if (!isOpen) return null;

  const handleInstallPwa = async () => {
    soundManager.playClick();
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      alert(
        'Untuk memasang sebagai APK / WebAPK di Android:\n1. Buka menu browser (titik 3 di kanan atas)\n2. Pilih "Tambahkan ke Layar Utama" / "Instal Aplikasi"\n3. Ikon GameSpace X akan otomatis muncul di app drawer Android Anda.'
      );
    }
  };

  const handleDownloadSh = () => {
    soundManager.playClick();
    const content = generateShizukuScript(systemTweaks);
    const blob = new Blob([content], { type: 'text/x-shellscript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'gamespace_x_daemon.sh';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadMagisk = () => {
    soundManager.playClick();
    const content = generateMagiskModuleScript();
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'gamespace_x_magisk_service.sh';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-2xl overflow-hidden rounded-2xl border border-cyan-500/30 bg-[#090d16] text-slate-200 shadow-2xl">
        <div className="h-1 w-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-pink-500" />

        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4 bg-[#0b101c]">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Smartphone className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Instalasi &amp; Ekspor APK GameSpace X
              </h2>
              <p className="text-xs text-slate-400">
                Kompatibel dengan semua ponsel Android (HyperOS, OneUI, ColorOS, RealmeUI, ROG)
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="rounded-lg p-2 text-slate-400 hover:text-white hover:bg-white/5 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 max-h-[60vh] overflow-y-auto space-y-4">
          {/* Option 1: Native WebAPK / Direct Android Installation */}
          <div className="p-4 rounded-xl border border-cyan-400/50 bg-gradient-to-r from-cyan-950/30 via-slate-900 to-slate-900">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-cyan-400 uppercase">
                    METODE 1 (LANGSUNG DI HP)
                  </span>
                  <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-1.5 py-0.5 rounded font-mono">
                    Instant WebAPK
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white mt-1">
                  Pasang Langsung ke Home Screen / App Drawer Android
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  Aplikasi ini siap diinstal menjadi aplikasi native mandiri (Standalone APK/PWA) tanpa perlu koneksi PC atau USB Debugging.
                </p>
              </div>

              <button
                onClick={handleInstallPwa}
                className="px-4 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center gap-2 shrink-0 shadow-lg shadow-cyan-500/20 transition active:scale-95"
              >
                <Sparkles className="h-4 w-4" />
                <span>Instal APK Sekarang</span>
              </button>
            </div>
          </div>

          {/* Option 2: Shizuku Daemon Script */}
          <div className="p-4 rounded-xl border border-white/10 bg-slate-900/40">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-emerald-400 uppercase">
                    METODE 2 (SHIZUKU RUNNER)
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white mt-1">
                  Download Daemon Script (<code className="text-xs text-emerald-300">gamespace_x_daemon.sh</code>)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Jalankan script ini di Termux, aShell, atau Shizuku Runner untuk mengaktifkan seluruh optimasi kernel, refresh rate 120Hz, dan GPU Vulkan.
                </p>
              </div>

              <button
                onClick={handleDownloadSh}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-emerald-600 hover:text-white text-xs font-mono text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 shrink-0 transition"
              >
                <Download className="h-4 w-4" />
                <span>Download .sh</span>
              </button>
            </div>
          </div>

          {/* Option 3: Magisk / KernelSU Module */}
          <div className="p-4 rounded-xl border border-white/10 bg-slate-900/40">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-pink-400 uppercase">
                    METODE 3 (ROOT MAGISK / KERNELSU)
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white mt-1">
                  Download Template Module Magisk / APatch
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Untuk pengguna Root: script startup otomatis di folder <code>/data/adb/service.d/</code> yang berjalan setiap ponsel booting.
                </p>
              </div>

              <button
                onClick={handleDownloadMagisk}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-pink-600 hover:text-white text-xs font-mono text-pink-300 border border-pink-500/30 flex items-center gap-1.5 shrink-0 transition"
              >
                <FolderArchive className="h-4 w-4" />
                <span>Download Module</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-white/10 bg-[#070b13] px-5 py-3">
          <span className="text-[11px] text-slate-400 font-mono">
            Support: Android 9.0 s/d Android 15 (ARM64-v8a)
          </span>
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
