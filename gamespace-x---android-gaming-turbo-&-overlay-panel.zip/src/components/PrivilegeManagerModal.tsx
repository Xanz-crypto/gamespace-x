import React, { useState } from 'react';
import {
  ShieldCheck,
  Terminal as TerminalIcon,
  Copy,
  Check,
  Download,
  AlertTriangle,
  Play,
  Cpu,
  Zap,
  RefreshCw,
  X,
  ExternalLink
} from 'lucide-react';
import { PrivilegeMode, TerminalLog, SystemTweakState } from '../types/gaming';
import {
  GAMING_COMMAND_PRESETS,
  generateShizukuScript,
  generateMagiskModuleScript
} from '../utils/shizukuCommands';
import { soundManager } from '../utils/audio';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  privilegeMode: PrivilegeMode;
  onSelectPrivilege: (mode: PrivilegeMode) => void;
  logs: TerminalLog[];
  onAddLog: (command: string, source: 'root' | 'shizuku' | 'system', output?: string) => void;
  systemTweaks: SystemTweakState;
}

export const PrivilegeManagerModal: React.FC<Props> = ({
  isOpen,
  onClose,
  privilegeMode,
  onSelectPrivilege,
  logs,
  onAddLog,
  systemTweaks
}) => {
  const [activeTab, setActiveTab] = useState<'status' | 'terminal' | 'guide' | 'presets'>('status');
  const [customCmd, setCustomCmd] = useState('');
  const [copiedScript, setCopiedScript] = useState(false);
  const [isSimulatingPermission, setIsSimulatingPermission] = useState(false);

  if (!isOpen) return null;

  const handleCopyScript = () => {
    soundManager.playClick();
    const script = generateShizukuScript(systemTweaks);
    navigator.clipboard.writeText(script);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  const handleRunCommand = (cmdText: string) => {
    if (!cmdText.trim()) return;
    soundManager.playClick();
    onAddLog(
      cmdText,
      privilegeMode === 'root' ? 'root' : 'shizuku',
      'Execution OK (Exit code: 0)'
    );
    setCustomCmd('');
  };

  const handleRequestPrivilege = (targetMode: PrivilegeMode) => {
    soundManager.playToggle(true);
    setIsSimulatingPermission(true);

    setTimeout(() => {
      setIsSimulatingPermission(false);
      onSelectPrivilege(targetMode);
      soundManager.playTurboBoost();

      onAddLog(
        targetMode === 'root'
          ? 'su -c id'
          : 'moe.shizuku.privileged.api.ShizukuService#checkPermission()',
        targetMode === 'root' ? 'root' : 'shizuku',
        `Privilege granted: uid=0(root) gid=0(root) / Shizuku Binder v13.5 Active.`
      );
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-md">
      <div className="relative w-full max-w-3xl overflow-hidden rounded-2xl border border-cyan-500/30 bg-[#090d16] text-slate-200 shadow-2xl shadow-cyan-950/80">
        {/* Top ambient strip */}
        <div className="h-1 w-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-pink-500" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4 bg-[#0b101c]">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Root &amp; Shizuku Privilege Core
              </h2>
              <p className="text-xs text-slate-400">
                Mode Akses Sistem Gaming Tingkat Tinggi untuk Semua Tipe Android
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="rounded-lg p-2 text-slate-400 hover:text-white hover:bg-white/5 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/10 bg-[#070a12] px-5">
          {[
            { id: 'status', label: 'Mode Akses' },
            { id: 'terminal', label: 'Terminal Live' },
            { id: 'presets', label: 'Daftar Perintah Game' },
            { id: 'guide', label: 'Panduan Shizuku' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                soundManager.playClick();
                setActiveTab(tab.id as any);
              }}
              className={`px-4 py-3 text-xs font-semibold tracking-wide border-b-2 transition ${
                activeTab === tab.id
                  ? 'border-cyan-400 text-cyan-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Modal Body */}
        <div className="p-5 max-h-[60vh] overflow-y-auto">
          {/* TAB 1: STATUS / MODE SELECTOR */}
          {activeTab === 'status' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Mode Shizuku (Wireless ADB) */}
                <div
                  className={`relative p-4 rounded-xl border transition ${
                    privilegeMode === 'shizuku'
                      ? 'border-cyan-400 bg-cyan-950/20 shadow-lg shadow-cyan-950/50'
                      : 'border-white/10 bg-slate-900/40 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-bold text-cyan-400 uppercase">
                      SHIZUKU (ADB)
                    </span>
                    <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-1.5 py-0.5 rounded font-mono">
                      Recommended
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white">Tanpa Root (No Root)</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Menggunakan Wireless ADB Binder API untuk mengeksekusi modifikasi sistem tanpa merusak garansi atau Knox.
                  </p>
                  <button
                    onClick={() => handleRequestPrivilege('shizuku')}
                    disabled={isSimulatingPermission && privilegeMode === 'shizuku'}
                    className={`mt-4 w-full py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
                      privilegeMode === 'shizuku'
                        ? 'bg-cyan-500 text-slate-950 shadow-sm'
                        : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                    }`}
                  >
                    {privilegeMode === 'shizuku' ? '✓ Mode Aktif' : 'Aktifkan Shizuku'}
                  </button>
                </div>

                {/* Mode Root (Magisk / KernelSU / APatch) */}
                <div
                  className={`relative p-4 rounded-xl border transition ${
                    privilegeMode === 'root'
                      ? 'border-red-400 bg-red-950/20 shadow-lg shadow-red-950/50'
                      : 'border-white/10 bg-slate-900/40 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-bold text-red-400 uppercase">
                      ROOT SU
                    </span>
                    <span className="text-[10px] bg-red-500/20 text-red-300 px-1.5 py-0.5 rounded font-mono">
                      Maximum Power
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white">Magisk / KernelSU</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Akses penuh Kernel, penghentian total engine thermal throttling, dan penguncian scaling governor CPU.
                  </p>
                  <button
                    onClick={() => handleRequestPrivilege('root')}
                    disabled={isSimulatingPermission && privilegeMode === 'root'}
                    className={`mt-4 w-full py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
                      privilegeMode === 'root'
                        ? 'bg-red-500 text-white shadow-sm'
                        : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                    }`}
                  >
                    {privilegeMode === 'root' ? '✓ Root Aktif (UID 0)' : 'Minta Akses SU Root'}
                  </button>
                </div>

                {/* Mode Standard */}
                <div
                  className={`relative p-4 rounded-xl border transition ${
                    privilegeMode === 'standard'
                      ? 'border-emerald-400 bg-emerald-950/20 shadow-lg'
                      : 'border-white/10 bg-slate-900/40 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-bold text-emerald-400 uppercase">
                      STANDARD
                    </span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono">
                      Safe
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white">Non-Root Safe</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Overlay in-game, pembersih RAM via Android System Intent, DNS switcher, dan fitur DND tanpa izin khusus.
                  </p>
                  <button
                    onClick={() => handleRequestPrivilege('standard')}
                    className={`mt-4 w-full py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
                      privilegeMode === 'standard'
                        ? 'bg-emerald-500 text-slate-950 shadow-sm'
                        : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                    }`}
                  >
                    {privilegeMode === 'standard' ? '✓ Mode Aktif' : 'Gunakan Standar'}
                  </button>
                </div>
              </div>

              {/* Status Details */}
              <div className="rounded-xl border border-white/10 bg-[#060910] p-4 space-y-2 text-xs font-mono">
                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-400">SELinux Enforcing Status:</span>
                  <span className="text-emerald-400 font-bold">Enforcing (Permissive Bypass Active)</span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-400">Shizuku IPC Binder Version:</span>
                  <span className="text-cyan-400 font-bold">v13.5.4 (moe.shizuku.privileged.api)</span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-400">Android Framework Level:</span>
                  <span className="text-slate-200">API 34 / Android 14+ (Compatible all OEM: HyperOS, ColorOS, OneUI, ROG)</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TERMINAL LIVE */}
          {activeTab === 'terminal' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
                  <TerminalIcon className="h-4 w-4 text-cyan-400" />
                  <span>Shell Console ({privilegeMode === 'root' ? 'root@android #:' : 'shizuku@android $:'})</span>
                </div>
                <button
                  onClick={handleCopyScript}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-cyan-300 transition"
                >
                  {copiedScript ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copiedScript ? 'Tersalin!' : 'Salin Script Shell'}</span>
                </button>
              </div>

              {/* Console Output Screen */}
              <div className="h-64 overflow-y-auto rounded-xl border border-white/10 bg-black p-3.5 font-mono text-xs text-slate-300 space-y-1.5 shadow-inner">
                <div className="text-slate-500"># GameSpace X Shell Stream [Ready]</div>
                {logs.map((log) => (
                  <div key={log.id} className="leading-relaxed">
                    <span className="text-slate-500">[{log.timestamp}]</span>{' '}
                    <span className={log.source === 'root' ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                      {log.source === 'root' ? 'root# ' : 'shizuku$ '}
                    </span>
                    <span className="text-slate-100">{log.command}</span>
                    {log.output && <div className="text-[11px] text-emerald-400 pl-4">→ {log.output}</div>}
                  </div>
                ))}
              </div>

              {/* Input custom command */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleRunCommand(customCmd);
                }}
                className="flex gap-2"
              >
                <div className="relative flex-1">
                  <span className="absolute left-3 top-2.5 font-mono text-xs text-cyan-400 font-bold">
                    {privilegeMode === 'root' ? '#' : '$'}
                  </span>
                  <input
                    type="text"
                    value={customCmd}
                    onChange={(e) => setCustomCmd(e.target.value)}
                    placeholder="Ketik perintah adb / su (contoh: pm trim-caches 1048576)..."
                    className="w-full rounded-lg border border-white/10 bg-black/60 pl-8 pr-3 py-2 text-xs font-mono text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase flex items-center gap-1.5 transition"
                >
                  <Play className="h-3.5 w-3.5 fill-current" />
                  <span>Jalankan</span>
                </button>
              </form>
            </div>
          )}

          {/* TAB 3: COMMAND PRESETS */}
          {activeTab === 'presets' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-400">
                Koleksi perintah optimasi performa game yang dieksekusi oleh GameSpace X secara real-time:
              </p>

              <div className="space-y-2">
                {GAMING_COMMAND_PRESETS.map((preset) => (
                  <div
                    key={preset.id}
                    className="p-3 rounded-xl border border-white/10 bg-slate-900/40 hover:border-cyan-500/30 transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{preset.name}</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300 uppercase">
                          {preset.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{preset.description}</p>
                      <code className="text-[10px] text-cyan-400/90 font-mono mt-1 block break-all">
                        {privilegeMode === 'root' ? preset.rootCommand : preset.shizukuCommand}
                      </code>
                    </div>

                    <button
                      onClick={() =>
                        handleRunCommand(
                          privilegeMode === 'root' ? preset.rootCommand : preset.shizukuCommand
                        )
                      }
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-xs font-mono text-slate-200 transition shrink-0"
                    >
                      Eksekusi Sekarang
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: SHIZUKU SETUP GUIDE */}
          {activeTab === 'guide' && (
            <div className="space-y-4 text-xs text-slate-300">
              <div className="p-3.5 rounded-xl border border-cyan-500/30 bg-cyan-950/20 text-cyan-200">
                <h4 className="font-bold text-white mb-1">Mengapa Menggunakan Shizuku?</h4>
                Shizuku memungkinkan aplikasi GameSpace X mengakses perintah ADB tingkat sistem (seperti kunci 120Hz, ubah resolusi GPU, matikan throttling, dan matikan background app) tanpa memerlukan root dan tanpa menyambungkan HP ke komputer berulang kali.
              </div>

              <div className="space-y-3 font-sans">
                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/40 border border-white/10">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-300 font-bold shrink-0">
                    1
                  </span>
                  <div>
                    <h5 className="font-bold text-white">Aktifkan Opsi Pengembang (Developer Options)</h5>
                    <p className="text-slate-400 mt-0.5">
                      Buka Pengaturan HP &gt; Tentang Ponsel &gt; Ketuk "Nomor Bentukan" (Build Number) sebanyak 7 kali berturut-turut.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/40 border border-white/10">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-300 font-bold shrink-0">
                    2
                  </span>
                  <div>
                    <h5 className="font-bold text-white">Nyalakan Debugging Nirkabel (Wireless Debugging)</h5>
                    <p className="text-slate-400 mt-0.5">
                      Hubungkan ponsel ke Wi-Fi. Masuk ke Opsi Pengembang &gt; Aktifkan Debugging Nirkabel.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/40 border border-white/10">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-300 font-bold shrink-0">
                    3
                  </span>
                  <div>
                    <h5 className="font-bold text-white">Hubungkan Shizuku App</h5>
                    <p className="text-slate-400 mt-0.5">
                      Buka aplikasi Shizuku, pilih "Pairing with Wireless Debugging", masukkan 6 digit kode dari notifikasi. Lalu ketuk "Start".
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/40 border border-white/10">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-300 font-bold shrink-0">
                    4
                  </span>
                  <div>
                    <h5 className="font-bold text-white">Izinkan GameSpace X</h5>
                    <p className="text-slate-400 mt-0.5">
                      GameSpace X otomatis terdeteksi di Shizuku. Berikan izin "Allow Always" dan nikmati performa gaming maksimal!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-white/10 bg-[#070b13] px-5 py-3">
          <span className="text-[11px] text-slate-400 font-mono">
            Active Mode:{' '}
            <strong className="text-cyan-400 uppercase">{privilegeMode}</strong>
          </span>
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
