import React, { useState } from 'react';
import {
  Play,
  SlidersHorizontal,
  Plus,
  Zap,
  Flame,
  Shield,
  Activity,
  Cpu,
  Tv,
  Check,
  X,
  Trash2,
  Sparkles
} from 'lucide-react';
import { GameItem, PerformanceMode, PrivilegeMode, SystemTweakState } from '../types/gaming';
import { soundManager } from '../utils/audio';

interface Props {
  games: GameItem[];
  onLaunchGame: (game: GameItem) => void;
  onUpdateGame: (game: GameItem) => void;
  onAddGame: (game: Omit<GameItem, 'id'>) => void;
  onDeleteGame: (id: string) => void;
  privilegeMode: PrivilegeMode;
  systemTweaks: SystemTweakState;
  onUpdateTweaks: (tweaks: Partial<SystemTweakState>) => void;
  onOpenPrivilegeModal: () => void;
  onOpenExportModal: () => void;
}

export const GameLauncherHub: React.FC<Props> = ({
  games,
  onLaunchGame,
  onUpdateGame,
  onAddGame,
  onDeleteGame,
  privilegeMode,
  systemTweaks,
  onUpdateTweaks,
  onOpenPrivilegeModal,
  onOpenExportModal
}) => {
  const [selectedGameForEdit, setSelectedGameForEdit] = useState<GameItem | null>(null);
  const [isAddGameOpen, setIsAddGameOpen] = useState(false);
  const [isBeastMode, setIsBeastMode] = useState(true);

  // Form for new game
  const [newGameName, setNewGameName] = useState('');
  const [newGamePackage, setNewGamePackage] = useState('');
  const [newGameCategory, setNewGameCategory] = useState('Esports');
  const [newGameTargetFps, setNewGameTargetFps] = useState<60 | 90 | 120 | 144>(120);

  const handleToggleBeastMode = () => {
    soundManager.playTurboBoost();
    const next = !isBeastMode;
    setIsBeastMode(next);
    onUpdateTweaks({
      governor: next ? 'performance' : 'schedutil',
      bypassThermal: next,
      touchSamplingBoost: next,
      refreshRate: next ? 120 : 90
    });
  };

  const handleCreateGame = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGameName.trim()) return;
    soundManager.playClick();

    onAddGame({
      name: newGameName,
      packageName: newGamePackage || `com.game.${newGameName.toLowerCase().replace(/\s+/g, '')}`,
      bannerUrl: '/src/assets/images/game_tactical_shooter_1793430499645.jpg',
      category: newGameCategory,
      genre: 'Action',
      targetFps: newGameTargetFps,
      performanceMode: 'beast',
      resolutionScale: 100,
      msaa4x: true,
      touchSamplingRate: 1000,
      customDns: 'cloudflare_gaming',
      playtimeHours: 0,
      lastPlayed: 'Baru ditambahkan'
    });

    setNewGameName('');
    setNewGamePackage('');
    setIsAddGameOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* HERO BEAST MODE TURBO BANNER */}
      <div className="relative overflow-hidden rounded-3xl border border-cyan-500/30 bg-gradient-to-r from-[#0a1020] via-[#0c1424] to-[#120a1f] p-5 sm:p-7 shadow-2xl shadow-cyan-950/40">
        {/* Futuristic glowing backdrop accents */}
        <div className="absolute top-0 right-0 -mt-12 -mr-12 h-64 w-64 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-12 h-48 w-48 rounded-full bg-pink-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
              <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold uppercase">
                {privilegeMode.toUpperCase()} PRIVILEGE ACTIVE
              </span>
              <span className="text-slate-400">·</span>
              <span className="text-emerald-400">All Android Architecture Ready</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-tight">
              Aura Beast Mode <span className="text-cyan-400">120 FPS Turbo</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Tingkatkan kinerja rendering GPU, kunci touch sampling rate 1000Hz, dan jalankan panel in-game secara real-time via Shizuku &amp; Root kernel injection.
            </p>

            <div className="pt-2 flex flex-wrap gap-4 text-xs font-mono text-slate-300">
              <div className="flex items-center gap-1.5">
                <Cpu className="h-4 w-4 text-cyan-400" />
                <span>Snapdragon / Dimensity Octa-Core</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Activity className="h-4 w-4 text-emerald-400" />
                <span>Vulkan 1.3 Pipeline</span>
              </div>
            </div>
          </div>

          {/* Beast Mode Toggle Button with Animated Turbine effect */}
          <div className="flex flex-col sm:flex-row items-center gap-4 w-full lg:w-auto">
            <button
              onClick={handleToggleBeastMode}
              className={`relative group overflow-hidden w-full sm:w-auto px-7 py-4 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-3 transition-all duration-300 active:scale-95 shadow-xl ${
                isBeastMode
                  ? 'bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 shadow-cyan-500/30'
                  : 'bg-slate-800 text-slate-200 border border-white/10 hover:border-cyan-400'
              }`}
            >
              <Zap className={`h-5 w-5 ${isBeastMode ? 'animate-bounce' : ''}`} />
              <div className="text-left">
                <div className="text-xs opacity-75 font-mono">STATUS ENGINE</div>
                <div className="text-sm font-black">
                  {isBeastMode ? 'BEAST TURBO AKTIF' : 'AKTIFKAN TURBO'}
                </div>
              </div>
            </button>

            <div className="flex gap-2 w-full sm:w-auto">
              <button
                onClick={() => {
                  soundManager.playClick();
                  onOpenPrivilegeModal();
                }}
                className="flex-1 sm:flex-none px-4 py-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-white/10 text-xs font-semibold text-cyan-300 transition"
              >
                Root / Shizuku
              </button>
              <button
                onClick={() => {
                  soundManager.playClick();
                  onOpenExportModal();
                }}
                className="flex-1 sm:flex-none px-4 py-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-white/10 text-xs font-semibold text-emerald-300 transition"
              >
                Pasang APK
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* GAMES LIBRARY SECTION */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              <span>Game Terpasang</span>
              <span className="text-xs font-mono text-cyan-400 font-semibold">({games.length})</span>
            </h2>
            <p className="text-xs text-slate-400">
              Pilih game untuk dimainkan dengan Game Space floating panel aktif
            </p>
          </div>

          <button
            onClick={() => {
              soundManager.playClick();
              setIsAddGameOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold transition active:scale-95"
          >
            <Plus className="h-4 w-4" />
            <span>Tambah Game</span>
          </button>
        </div>

        {/* Game Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {games.map((game) => (
            <div
              key={game.id}
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-[#0a0e18] hover:border-cyan-500/40 transition-all duration-300 shadow-lg flex flex-col justify-between"
            >
              {/* Game Banner Thumbnail */}
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-slate-900">
                <img
                  src={game.bannerUrl}
                  alt={game.name}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0e18] via-transparent to-black/30" />

                {/* Top Badge: Target FPS & Mode */}
                <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                  <span className="rounded bg-black/70 backdrop-blur-xs px-2 py-0.5 text-[10px] font-mono font-bold text-cyan-400 border border-cyan-500/30">
                    {game.targetFps} FPS
                  </span>
                  <span className="rounded bg-black/70 backdrop-blur-xs px-2 py-0.5 text-[10px] font-mono text-emerald-300 border border-white/10 uppercase">
                    {game.performanceMode}
                  </span>
                </div>

                {/* Edit Config Icon */}
                <button
                  onClick={() => {
                    soundManager.playClick();
                    setSelectedGameForEdit(game);
                  }}
                  className="absolute top-2.5 right-2.5 h-7 w-7 rounded-lg bg-black/70 backdrop-blur-xs text-slate-300 hover:text-white hover:bg-black flex items-center justify-center transition border border-white/10"
                  title="Pengaturan Profil Game"
                >
                  <SlidersHorizontal className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Game Info Body */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="text-sm font-bold text-white tracking-tight line-clamp-1 group-hover:text-cyan-300 transition">
                    {game.name}
                  </h3>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5 font-mono">
                    <span>{game.category}</span>
                    <span>·</span>
                    <span>Touch {game.touchSamplingRate}Hz</span>
                  </div>
                </div>

                {/* Action CTA: Launch into Interactive Simulator */}
                <button
                  onClick={() => {
                    soundManager.playTurboBoost();
                    onLaunchGame(game);
                  }}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md shadow-cyan-500/10 active:scale-95 transition"
                >
                  <Play className="h-4 w-4 fill-current" />
                  <span>Mainkan (HUD Aktif)</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* MODAL: ADD GAME */}
      {isAddGameOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
          <div className="w-full max-w-md rounded-2xl border border-cyan-500/30 bg-[#090d16] p-5 text-slate-200 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-sm font-bold text-white">Tambah Game Baru ke Game Space</h3>
              <button
                onClick={() => setIsAddGameOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleCreateGame} className="mt-4 space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Nama Game</label>
                <input
                  type="text"
                  required
                  value={newGameName}
                  onChange={(e) => setNewGameName(e.target.value)}
                  placeholder="Contoh: Free Fire MAX, eFootball, CODM..."
                  className="w-full rounded-lg border border-white/10 bg-black/60 px-3 py-2 text-xs text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">Package Name (Opsional)</label>
                <input
                  type="text"
                  value={newGamePackage}
                  onChange={(e) => setNewGamePackage(e.target.value)}
                  placeholder="Contoh: com.dts.freefireth"
                  className="w-full rounded-lg border border-white/10 bg-black/60 px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Kategori</label>
                  <select
                    value={newGameCategory}
                    onChange={(e) => setNewGameCategory(e.target.value)}
                    className="w-full rounded-lg border border-white/10 bg-black/60 px-3 py-2 text-xs text-white focus:border-cyan-400 focus:outline-none"
                  >
                    <option value="Esports">Esports MOBA</option>
                    <option value="Battle Royale">Battle Royale</option>
                    <option value="Shooter FPS">Shooter FPS</option>
                    <option value="Open World RPG">Open World RPG</option>
                    <option value="Racing">Racing Simulation</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">Target FPS</label>
                  <select
                    value={newGameTargetFps}
                    onChange={(e) => setNewGameTargetFps(Number(e.target.value) as any)}
                    className="w-full rounded-lg border border-white/10 bg-black/60 px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                  >
                    <option value="60">60 FPS</option>
                    <option value="90">90 FPS</option>
                    <option value="120">120 FPS</option>
                    <option value="144">144 FPS</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddGameOpen(false)}
                  className="px-3 py-2 rounded-lg bg-slate-800 text-xs text-slate-300 hover:bg-slate-700"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase"
                >
                  Simpan Game
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDIT GAME CONFIG */}
      {selectedGameForEdit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl border border-cyan-500/30 bg-[#090d16] p-5 text-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white">{selectedGameForEdit.name}</h3>
                <span className="text-[11px] font-mono text-slate-400">
                  {selectedGameForEdit.packageName}
                </span>
              </div>
              <button
                onClick={() => setSelectedGameForEdit(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Target Frame Rate (FPS)</label>
                <div className="grid grid-cols-4 gap-2 font-mono">
                  {([60, 90, 120, 144] as const).map((fps) => (
                    <button
                      key={fps}
                      type="button"
                      onClick={() =>
                        setSelectedGameForEdit({ ...selectedGameForEdit, targetFps: fps })
                      }
                      className={`py-1.5 rounded-lg border text-center transition ${
                        selectedGameForEdit.targetFps === fps
                          ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300 font-bold'
                          : 'border-white/10 bg-slate-900 text-slate-400'
                      }`}
                    >
                      {fps} FPS
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Touch Polling Rate</label>
                <div className="grid grid-cols-3 gap-2 font-mono">
                  {([480, 720, 1000] as const).map((hz) => (
                    <button
                      key={hz}
                      type="button"
                      onClick={() =>
                        setSelectedGameForEdit({ ...selectedGameForEdit, touchSamplingRate: hz })
                      }
                      className={`py-1.5 rounded-lg border text-center transition ${
                        selectedGameForEdit.touchSamplingRate === hz
                          ? 'border-emerald-400 bg-emerald-950/40 text-emerald-300 font-bold'
                          : 'border-white/10 bg-slate-900 text-slate-400'
                      }`}
                    >
                      {hz} Hz
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Skala Resolusi Render GPU</label>
                <div className="grid grid-cols-3 gap-2 font-mono">
                  {([75, 85, 100] as const).map((scale) => (
                    <button
                      key={scale}
                      type="button"
                      onClick={() =>
                        setSelectedGameForEdit({ ...selectedGameForEdit, resolutionScale: scale })
                      }
                      className={`py-1.5 rounded-lg border text-center transition ${
                        selectedGameForEdit.resolutionScale === scale
                          ? 'border-pink-400 bg-pink-950/40 text-pink-300 font-bold'
                          : 'border-white/10 bg-slate-900 text-slate-400'
                      }`}
                    >
                      {scale}% Scale
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  onDeleteGame(selectedGameForEdit.id);
                  setSelectedGameForEdit(null);
                }}
                className="flex items-center gap-1.5 text-xs text-red-400 hover:text-red-300"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Hapus Game</span>
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedGameForEdit(null)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs text-slate-300 hover:bg-slate-700"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onUpdateGame(selectedGameForEdit);
                    setSelectedGameForEdit(null);
                  }}
                  className="px-4 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase"
                >
                  Simpan Profil
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
