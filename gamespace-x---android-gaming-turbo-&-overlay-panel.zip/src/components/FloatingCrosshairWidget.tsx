import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Crosshair,
  Lock,
  Unlock,
  RotateCcw,
  Eye,
  EyeOff,
  Palette,
  Move,
  Sliders,
  X
} from 'lucide-react';
import { CrosshairConfig, CrosshairStyle } from '../types/gaming';
import { soundManager } from '../utils/audio';

interface Props {
  config: CrosshairConfig;
  onUpdateConfig: (config: Partial<CrosshairConfig>) => void;
  containerRef: React.RefObject<HTMLDivElement | null>;
  onAddLog?: (command: string, source: 'root' | 'shizuku' | 'system', output?: string) => void;
}

export const FloatingCrosshairWidget: React.FC<Props> = ({
  config,
  onUpdateConfig,
  containerRef,
  onAddLog
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [showQuickMenu, setShowQuickMenu] = useState(false);
  const [touchFeedback, setTouchFeedback] = useState<string | null>(null);

  // Default position: 50% X, 50% Y (dead center)
  const posX = config.position?.x ?? 50;
  const posY = config.position?.y ?? 50;
  const isLocked = config.isLocked ?? false;

  const dragStartRef = useRef<{ clientX: number; clientY: number; startX: number; startY: number } | null>(null);

  // Pointer drag handler (works seamlessly for both touch and mouse)
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isLocked) return;
    e.preventDefault();
    e.stopPropagation();

    try {
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      // fallback
    }

    dragStartRef.current = {
      clientX: e.clientX,
      clientY: e.clientY,
      startX: posX,
      startY: posY
    };

    setIsDragging(true);
    soundManager.playClick();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging || !dragStartRef.current || !containerRef.current) return;
    e.preventDefault();

    const rect = containerRef.current.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    // Calculate new position as percentage of container
    const deltaX = ((e.clientX - dragStartRef.current.clientX) / rect.width) * 100;
    const deltaY = ((e.clientY - dragStartRef.current.clientY) / rect.height) * 100;

    // Clamp between 5% and 95% so it doesn't get lost outside viewport
    const newX = Math.min(95, Math.max(5, dragStartRef.current.startX + deltaX));
    const newY = Math.min(95, Math.max(5, dragStartRef.current.startY + deltaY));

    onUpdateConfig({
      position: {
        x: Number(newX.toFixed(2)),
        y: Number(newY.toFixed(2))
      }
    });
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // fallback
    }
    setIsDragging(false);
    dragStartRef.current = null;
    soundManager.playClick();
  };

  // Reset reticle back to exact screen center (50%, 50%)
  const handleResetCenter = () => {
    soundManager.playClick();
    onUpdateConfig({
      position: { x: 50, y: 50 }
    });
    setTouchFeedback('Centered (50%, 50%)');
    setTimeout(() => setTouchFeedback(null), 1200);

    if (onAddLog) {
      onAddLog(
        'overlay crosshair set-position --center',
        'system',
        'Crosshair calibrated to screen center'
      );
    }
  };

  // Toggle lock state (prevents accidental movement while aiming/shooting)
  const handleToggleLock = () => {
    soundManager.playToggle(!isLocked);
    const nextLocked = !isLocked;
    onUpdateConfig({ isLocked: nextLocked });
    setTouchFeedback(nextLocked ? 'Posisi Terkunci' : 'Posisi Dibuka (Dapat Digeser)');
    setTimeout(() => setTouchFeedback(null), 1200);
  };

  // Toggle global visibility
  const handleToggleVisibility = () => {
    soundManager.playToggle(!config.enabled);
    onUpdateConfig({ enabled: !config.enabled });
  };

  // Cycle styles
  const handleCycleStyle = () => {
    soundManager.playClick();
    const styles: CrosshairStyle[] = ['classic_cross', 'red_dot', 'tactical_circle', 'chevron', 'cyber_reticle'];
    const currentIndex = styles.indexOf(config.style);
    const nextStyle = styles[(currentIndex + 1) % styles.length];
    onUpdateConfig({ style: nextStyle });
  };

  // Cycle colors
  const handleCycleColor = () => {
    soundManager.playClick();
    const colors = ['#00F0FF', '#FF0055', '#00FF9D', '#FFB703', '#FFFFFF'];
    const curIdx = colors.indexOf(config.color);
    const nextColor = colors[(curIdx + 1) % colors.length];
    onUpdateConfig({ color: nextColor });
  };

  const { style, color, size, thickness, opacity } = config;

  return (
    <>
      {/* GLOBAL FLOATING CROSSHAIR WIDGET (Top layer, remains visible above gameplay & buttons) */}
      {config.enabled && (
        <div
          className="absolute z-50 pointer-events-auto select-none"
          style={{
            left: `${posX}%`,
            top: `${posY}%`,
            transform: 'translate(-50%, -50%)',
            touchAction: 'none'
          }}
        >
          {/* Draggable Anchor Hitbox */}
          <div
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            className={`relative flex items-center justify-center cursor-grab active:cursor-grabbing p-3 rounded-full transition-shadow ${
              isDragging ? 'ring-2 ring-cyan-400 bg-cyan-950/40 ring-offset-2 ring-offset-black' : ''
            }`}
            style={{
              width: `${Math.max(size + 24, 48)}px`,
              height: `${Math.max(size + 24, 48)}px`
            }}
            title={isLocked ? 'Crosshair terkunci (Buka kunci untuk memindahkan)' : 'Sentuh dan geser untuk mengatur posisi crosshair'}
          >
            {/* CROSSHAIR RETICLE GRAPHIC */}
            <div style={{ opacity, pointerEvents: 'none' }}>
              {style === 'red_dot' && (
                <div
                  className="rounded-full shadow-sm"
                  style={{
                    width: `${size / 3}px`,
                    height: `${size / 3}px`,
                    backgroundColor: color,
                    boxShadow: `0 0 10px ${color}`
                  }}
                />
              )}

              {style === 'classic_cross' && (
                <div
                  className="relative flex items-center justify-center"
                  style={{ width: `${size}px`, height: `${size}px` }}
                >
                  <div
                    className="absolute rounded-full"
                    style={{
                      width: `${size}px`,
                      height: `${thickness}px`,
                      backgroundColor: color,
                      boxShadow: `0 0 6px ${color}`
                    }}
                  />
                  <div
                    className="absolute rounded-full"
                    style={{
                      height: `${size}px`,
                      width: `${thickness}px`,
                      backgroundColor: color,
                      boxShadow: `0 0 6px ${color}`
                    }}
                  />
                  <div
                    className="absolute rounded-full"
                    style={{
                      width: `${thickness + 1}px`,
                      height: `${thickness + 1}px`,
                      backgroundColor: color
                    }}
                  />
                </div>
              )}

              {style === 'tactical_circle' && (
                <div
                  className="relative flex items-center justify-center rounded-full"
                  style={{
                    width: `${size}px`,
                    height: `${size}px`,
                    border: `${thickness}px solid ${color}`,
                    boxShadow: `0 0 8px ${color}`
                  }}
                >
                  <div
                    className="rounded-full"
                    style={{
                      width: `${thickness * 2}px`,
                      height: `${thickness * 2}px`,
                      backgroundColor: color
                    }}
                  />
                </div>
              )}

              {style === 'chevron' && (
                <svg
                  width={size}
                  height={size}
                  viewBox="0 0 32 32"
                  fill="none"
                  style={{ filter: `drop-shadow(0 0 4px ${color})` }}
                >
                  <path
                    d="M8 20L16 10L24 20"
                    stroke={color}
                    strokeWidth={thickness}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <circle cx="16" cy="16" r={thickness / 1.5} fill={color} />
                </svg>
              )}

              {style === 'cyber_reticle' && (
                <svg
                  width={size}
                  height={size}
                  viewBox="0 0 40 40"
                  fill="none"
                  style={{ filter: `drop-shadow(0 0 5px ${color})` }}
                >
                  <path d="M10 6H6V10" stroke={color} strokeWidth={thickness} strokeLinecap="round" />
                  <path d="M30 6H34V10" stroke={color} strokeWidth={thickness} strokeLinecap="round" />
                  <path d="M10 34H6V30" stroke={color} strokeWidth={thickness} strokeLinecap="round" />
                  <path d="M30 34H34V30" stroke={color} strokeWidth={thickness} strokeLinecap="round" />
                  <circle cx="20" cy="20" r={thickness} fill={color} />
                </svg>
              )}
            </div>

            {/* Position coordinate indicator when dragging */}
            {isDragging && (
              <div className="pointer-events-none absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-black/80 px-2 py-0.5 font-mono text-[9px] text-cyan-300 border border-cyan-500/40">
                X: {Math.round(posX)}% Y: {Math.round(posY)}%
              </div>
            )}
          </div>
        </div>
      )}

      {/* FLOATING QUICK CALIBRATION DOCK (Persistent in top-right corner of game view) */}
      <div className="absolute top-3 right-3 z-45 flex items-center gap-1.5 bg-[#080d18]/90 border border-cyan-500/30 rounded-xl p-1 backdrop-blur-md shadow-lg shadow-black/60 pointer-events-auto">
        {/* Global Crosshair Visibility Toggle */}
        <button
          onClick={handleToggleVisibility}
          className={`px-2.5 py-1.5 rounded-lg text-xs font-bold font-mono flex items-center gap-1.5 transition ${
            config.enabled
              ? 'bg-cyan-500 text-slate-950 shadow-sm'
              : 'bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700'
          }`}
          title={config.enabled ? 'Sembunyikan Crosshair' : 'Tampilkan Floating Crosshair'}
        >
          {config.enabled ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
          <span className="hidden sm:inline">{config.enabled ? 'AIM ON' : 'AIM OFF'}</span>
        </button>

        {/* When enabled, show quick touch actions */}
        {config.enabled && (
          <>
            {/* Lock / Unlock Position */}
            <button
              onClick={handleToggleLock}
              className={`p-1.5 rounded-lg transition ${
                isLocked
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-slate-800 text-slate-300 hover:text-cyan-300 hover:bg-slate-700'
              }`}
              title={isLocked ? 'Buka kunci untuk memindahkan posisi crosshair' : 'Kunci posisi crosshair agar tidak bergeser saat bermain'}
            >
              {isLocked ? <Lock className="h-3.5 w-3.5" /> : <Unlock className="h-3.5 w-3.5" />}
            </button>

            {/* Reset to Center */}
            <button
              onClick={handleResetCenter}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-cyan-300 hover:bg-slate-700 transition"
              title="Kembalikan crosshair ke posisi tengah layar (50%, 50%)"
            >
              <RotateCcw className="h-3.5 w-3.5" />
            </button>

            {/* Quick Cycle Style */}
            <button
              onClick={handleCycleStyle}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-cyan-300 hover:bg-slate-700 transition"
              title="Ganti gaya reticle crosshair"
            >
              <Crosshair className="h-3.5 w-3.5" />
            </button>

            {/* Quick Cycle Color */}
            <button
              onClick={handleCycleColor}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
              title="Ganti warna reticle"
            >
              <div
                className="h-3.5 w-3.5 rounded-full border border-white/40"
                style={{ backgroundColor: config.color }}
              />
            </button>
          </>
        )}
      </div>

      {/* Tactile Feedback Banner */}
      {touchFeedback && (
        <div className="pointer-events-none absolute top-14 right-3 z-50 rounded-lg bg-cyan-500 px-3 py-1 text-xs font-bold text-slate-950 shadow-lg animate-fade-in font-mono">
          {touchFeedback}
        </div>
      )}
    </>
  );
};
