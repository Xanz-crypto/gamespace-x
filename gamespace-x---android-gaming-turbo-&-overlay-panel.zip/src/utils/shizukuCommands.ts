/**
 * GameSpace X - Shizuku & Root Command Database and Script Generators
 */

import { PrivilegeMode, SystemTweakState, TerminalLog } from '../types/gaming';

export interface CommandPreset {
  id: string;
  name: string;
  category: 'performance' | 'display' | 'touch' | 'thermal' | 'ram';
  shizukuCommand: string;
  rootCommand: string;
  description: string;
}

export const GAMING_COMMAND_PRESETS: CommandPreset[] = [
  {
    id: 'fixed_performance',
    name: 'Fixed High Performance Mode',
    category: 'performance',
    shizukuCommand: 'cmd power set-fixed-performance-mode-enabled true',
    rootCommand: 'cmd power set-fixed-performance-mode-enabled true && echo performance > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor',
    description: 'Forces all CPU cores and big.LITTLE cluster out of power saving throttles'
  },
  {
    id: 'refresh_rate_120',
    name: 'Force Peak 120Hz Refresh Rate',
    category: 'display',
    shizukuCommand: 'settings put system peak_refresh_rate 120.0 && settings put system min_refresh_rate 120.0',
    rootCommand: 'settings put system peak_refresh_rate 120.0 && settings put system min_refresh_rate 120.0',
    description: 'Eliminates dynamic refresh rate drops and locks display to 120 FPS'
  },
  {
    id: 'touch_sampling_1000',
    name: 'Ultra Touch Sampling Boost (1000Hz)',
    category: 'touch',
    shizukuCommand: 'setprop persist.vendor.touch.sampling_rate 1000 && settings put system touch_prediction_timeout 2',
    rootCommand: 'setprop persist.vendor.touch.sampling_rate 1000 && echo 1000 > /sys/devices/virtual/touch/touch_dev/sampling_rate',
    description: 'Minimizes touch input latency for instant aim and reaction'
  },
  {
    id: 'thermal_throttle_disable',
    name: 'Bypass Thermal Throttling',
    category: 'thermal',
    shizukuCommand: 'dumpsys thermalservice override-status 0',
    rootCommand: 'stop thermal-engine && stop thermald && dumpsys thermalservice override-status 0',
    description: 'Overrides Android thermal HAL shutdown thresholds during heavy gaming'
  },
  {
    id: 'vulkan_render_pipeline',
    name: 'SkiaVK Vulkan 1.3 Hardware Acceleration',
    category: 'performance',
    shizukuCommand: 'setprop debug.hwui.renderer skiavk && setprop debug.renderengine.backend skiaglthreaded',
    rootCommand: 'setprop debug.hwui.renderer skiavk && setprop debug.renderengine.backend skiaglthreaded',
    description: 'Switches system render engine to low-overhead Vulkan pipeline'
  },
  {
    id: 'frame_drop_pacing',
    name: 'Zero Jitter Frame Latching',
    category: 'display',
    shizukuCommand: 'setprop debug.sf.latch_unsignaled 1 && setprop debug.sf.enable_gl_backpressure 0',
    rootCommand: 'setprop debug.sf.latch_unsignaled 1 && setprop debug.sf.enable_gl_backpressure 0',
    description: 'Reduces SurfaceFlinger buffer latency and dropped frame stutter'
  },
  {
    id: 'ram_drop_caches',
    name: 'ZRAM & Kernel Buffer Purge',
    category: 'ram',
    shizukuCommand: 'am kill-all && pm trim-caches 2147483648',
    rootCommand: 'am kill-all && sync && echo 3 > /proc/sys/vm/drop_caches && sysctl -w vm.swappiness=80',
    description: 'Frees dirty RAM pages, kills background cached tasks, optimizes swap'
  },
  {
    id: 'battery_bypass_sim',
    name: 'Direct Power / Thermal Bypass',
    category: 'thermal',
    shizukuCommand: 'dumpsys battery unplug',
    rootCommand: 'echo 0 > /sys/class/power_supply/battery/charging_enabled && dumpsys battery unplug',
    description: 'Simulates bypass charging directly from wall charger to reduce heat'
  }
];

/**
 * Builds commands based on system tweak state
 */
export function buildTweakCommands(tweaks: SystemTweakState, mode: PrivilegeMode): string[] {
  const cmds: string[] = [];

  if (tweaks.refreshRate) {
    cmds.push(`settings put system peak_refresh_rate ${tweaks.refreshRate}.0`);
    cmds.push(`settings put system min_refresh_rate ${tweaks.refreshRate}.0`);
  }

  if (tweaks.gpuRenderer === 'vulkan' || tweaks.gpuRenderer === 'skiavk') {
    cmds.push('setprop debug.hwui.renderer skiavk');
  } else {
    cmds.push('setprop debug.hwui.renderer opengl');
  }

  if (tweaks.framePacingBuffer) {
    cmds.push('setprop debug.sf.latch_unsignaled 1');
    cmds.push('setprop debug.sf.enable_gl_backpressure 0');
  }

  if (tweaks.touchSamplingBoost) {
    cmds.push(`setprop persist.vendor.touch.sampling_rate ${tweaks.samplingRate}`);
  }

  if (tweaks.bypassThermal) {
    if (mode === 'root') {
      cmds.push('stop thermal-engine; stop thermald; dumpsys thermalservice override-status 0');
    } else {
      cmds.push('dumpsys thermalservice override-status 0');
    }
  }

  if (tweaks.screenResolution === '720p') {
    cmds.push('wm size 720x1600 && wm density 280');
  } else if (tweaks.screenResolution === '1080p') {
    cmds.push('wm size 1080x2400 && wm density 420');
  } else if (tweaks.screenResolution === 'native') {
    cmds.push('wm size reset && wm density reset');
  }

  if (tweaks.governor === 'performance' && mode === 'root') {
    cmds.push('for c in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo performance > "$c"; done');
  }

  return cmds;
}

/**
 * Generates ready-to-run shell script for Shizuku Runner, aShell, or Termux
 */
export function generateShizukuScript(tweaks: SystemTweakState): string {
  return `#!/bin/sh
# =========================================================
# GameSpace X - Universal Android Gaming Optimizer Daemon
# Compatible: Shizuku / aShell / Termux / ADB Shell / Root
# =========================================================

echo "[GameSpace X] Initializing Gaming Engine..."

# 1. Performance Governors & CPU Boost
cmd power set-fixed-performance-mode-enabled true
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_gl_backpressure 0

# 2. Display Refresh Rate Lock (${tweaks.refreshRate}Hz)
settings put system peak_refresh_rate ${tweaks.refreshRate}.0
settings put system min_refresh_rate ${tweaks.refreshRate}.0

# 3. Touch Latency Optimization (${tweaks.samplingRate}Hz)
setprop persist.vendor.touch.sampling_rate ${tweaks.samplingRate}
settings put system touch_prediction_timeout 2

# 4. GPU Hardware Backend (${tweaks.gpuRenderer})
setprop debug.hwui.renderer ${tweaks.gpuRenderer === 'opengl' ? 'opengl' : 'skiavk'}

# 5. Thermal Throttling Override
dumpsys thermalservice override-status 0

# 6. Aggressive Background Cache Killer
am kill-all
pm trim-caches 1073741824

echo "[GameSpace X] Gaming Turbo Activated Successfully! 🚀"
`;
}

/**
 * Generates Magisk / KernelSU module structure definition
 */
export function generateMagiskModuleScript(): string {
  return `# Magisk / KernelSU GameSpace X Module
id=gamespace_x_optimizer
name=GameSpace X Gaming Kernel Tweak
version=v3.5.0
versionCode=350
author=GameSpace X Team
description=Universal Game Turbo optimizer, 1000Hz touch boost, Vulkan backend, and CPU schedutil governor lock.

# service.sh executed at boot:
#!/system/bin/sh
MODDIR=\${0%/*}
sleep 15

# Force performance governor
for g in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    echo performance > "$g"
done

# Thermal engine bypass
stop thermal-engine
stop thermald
dumpsys thermalservice override-status 0

# Touch and SurfaceFlinger tuning
setprop debug.sf.latch_unsignaled 1
setprop persist.vendor.touch.sampling_rate 1000
setprop debug.hwui.renderer skiavk
`;
}
