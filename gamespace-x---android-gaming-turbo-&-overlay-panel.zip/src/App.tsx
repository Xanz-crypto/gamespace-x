/**
 * GameSpace X - Universal Android Gaming Turbo & Real-Time In-Game HUD Panel
 */

import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  Cpu,
  ShieldCheck,
  Download,
  Volume2,
  VolumeX,
  Sparkles,
  Smartphone,
  Play,
  Crosshair
} from 'lucide-react';
import {
  GameItem,
  TelemetryData,
  SystemTweakState,
  PrivilegeMode,
  CrosshairConfig,
  TerminalLog
} from './types/gaming';
import { INITIAL_GAMES } from './data/mockGames';
import { soundManager } from './utils/audio';
import { GameLauncherHub } from './components/GameLauncherHub';
import { DeviceSimulatorView } from './components/DeviceSimulatorView';
import { SystemTweaksTab } from './components/SystemTweaksTab';
import { PrivilegeManagerModal } from './components/PrivilegeManagerModal';
import { ApkExportModal } from './components/ApkExportModal';
import { InGameOverlayPanel } from './components/InGameOverlayPanel';

export default function App() {
  const [activeView, setActiveView] = useState<'hub' | 'simulator' | 'tweaks'>('hub');
  const [games, setGames] = useState<GameItem[]>(INITIAL_GAMES);
  const [activeGame, setActiveGame] = useState<GameItem>(INITIAL_GAMES[0]);
  const [privilegeMode, setPrivilegeMode] = useState<PrivilegeMode>('shizuku');
  const [isPrivilegeModalOpen, setIsPrivilegeModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Global overlay HUD toggle (can be opened from any view)
  const [isGlobalOverlayOpen, setIsGlobalOverlayOpen] = useState(false);

  // System Tweaks State
  const [systemTweaks, setSystemTweaks] = useState<SystemTweakState>({
    dndCalls: true,
    dndNotifications: true,
    lockGestures: true,
    lockBrightness: true,
    brightnessValue: 90,
    bypassCharging: false,
    bypassThermal: true,
    touchSamplingBoost: true,
    samplingRate: 1000,
    refreshRate: 120,
    gpuRenderer: 'skiavk',
    activeDns: 'cloudflare_gaming',
    governor: 'performance',
    screenResolution: '1080p',
    zramOptimized: true,
    framePacingBuffer: true
  });

  // Crosshair Config State
  const [crosshairConfig, setCrosshairConfig] = useState<CrosshairConfig>({
    enabled: true,
    style: 'classic_cross',
    color: '#00F0FF',
    size: 26,
    thickness: 2,
    opacity: 0.9,
    position: { x: 50, y: 50 },
    isLocked: false
  });

  // Real-Time Live Telemetry State
  const [telemetry, setTelemetry] = useState<TelemetryData>({
    fps: 119.4,
    targetFps: 120,
    frameHistory: [118, 119, 120, 119, 120, 120, 118, 119, 120, 117, 120, 119, 120, 120, 119, 120],
    cpuUsage: 48,
    cpuTempC: 37.8,
    cpuFreqGhz: 2.84,
    gpuUsage: 64,
    gpuFreqMhz: 680,
    ramUsedGb: 6.8,
    ramTotalGb: 12.0,
    pingMs: 24,
    jitterMs: 1.4,
    packetLoss: 0.0,
    batteryPct: 82,
    isBypassCharging: false,
    fanSpeedRpm: 4200
  });

  // Live Terminal Logs
  const [logs, setLogs] = useState<TerminalLog[]>([
    {
      id: 'log-1',
      timestamp: '19:40:02',
      command: 'moe.shizuku.privileged.api.ShizukuService#bindService()',
      source: 'shizuku',
      status: 'success',
      output: 'IPC Binder Connected: AIDL Service v13'
    },
    {
      id: 'log-2',
      timestamp: '19:40:03',
      command: 'settings put system peak_refresh_rate 120.0',
      source: 'shizuku',
      status: 'success',
      output: 'Peak refresh rate locked to 120Hz'
    },
    {
      id: 'log-3',
      timestamp: '19:40:04',
      command: 'setprop debug.hwui.renderer skiavk',
      source: 'shizuku',
      status: 'success',
      output: 'Hardware Vulkan SkiaVK acceleration forced'
    }
  ]);

  const addLog = (command: string, source: 'root' | 'shizuku' | 'system', output?: string) => {
    const time = new Date().toTimeString().split(' ')[0];
    const newLog: TerminalLog = {
      id: `log-${Date.now()}-${Math.random()}`,
      timestamp: time,
      command,
      source,
      status: 'success',
      output
    };
    setLogs((prev) => [newLog, ...prev.slice(0, 40)]);
  };

  const handleUpdateTweaks = (updated: Partial<SystemTweakState>) => {
    setSystemTweaks((prev) => ({ ...prev, ...updated }));
  };

  const handleUpdateCrosshair = (updated: Partial<CrosshairConfig>) => {
    setCrosshairConfig((prev) => ({ ...prev, ...updated }));
  };

  // Real-Time Telemetry Simulation Tick
  useEffect(() => {
    const interval = setInterval(() => {
      setTelemetry((prev) => {
        const target = activeGame.targetFps;
        // Minor realistic frame fluctuation
        const delta = (Math.random() - 0.48) * 2.2;
        const newFps = Math.min(target, Math.max(target - 4, prev.fps + delta));
        const newHistory = [...prev.frameHistory.slice(1), Math.round(newFps)];

        // Heat accumulation logic (slower if thermal bypass or low power)
        const heatDelta = systemTweaks.bypassThermal ? 0.02 : 0.05;
        const currentTemp = Math.min(46.0, Math.max(36.5, prev.cpuTempC + (Math.random() - 0.49) * 0.1));

        return {
          ...prev,
          fps: Number(newFps.toFixed(1)),
          targetFps: target,
          frameHistory: newHistory,
          cpuUsage: Math.min(92, Math.max(38, Math.round(prev.cpuUsage + (Math.random() - 0.5) * 4))),
          gpuUsage: Math.min(96, Math.max(45, Math.round(prev.gpuUsage + (Math.random() - 0.5) * 5))),
          cpuTempC: Number(currentTemp.toFixed(1)),
          pingMs: Math.min(65, Math.max(16, prev.pingMs + (Math.random() - 0.5) * 2.5)),
          jitterMs: Number((1.0 + Math.random() * 0.8).toFixed(1))
        };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [activeGame, systemTweaks.bypassThermal]);

  const handleLaunchGame = (game: GameItem) => {
    setActiveGame(game);
    setActiveView('simulator');
    addLog(
      `am start -n ${game.packageName}/.MainActivity --es "flags" "GAME_TURBO_PRIORITY"`,
      privilegeMode === 'root' ? 'root' : 'shizuku',
      `Allocated top OOM priority -1000 for ${game.name}`
    );
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* 
        ZONE 1-2-3 TOP BAR CONTRACT:
        [Brand wordmark, one line] — [4-5 single-line nav links] — [1 primary CTA]
      */}
      <header className="sticky top-0 z-40 flex items-center justify-between gap-8 px-4 sm:px-8 py-3.5 border-b border-white/10 bg-[#07090e]/90 backdrop-blur-md">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            soundManager.playClick();
            setActiveView('hub');
          }}
          className="text-lg font-black tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2 group"
        >
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-400/40 text-cyan-400 group-hover:scale-105 transition">
            <Gamepad2 className="h-4 w-4" />
          </span>
          <span className="font-extrabold tracking-wider">
            GameSpace<span className="text-cyan-400">X</span>
          </span>
        </a>

        {/* Zone 2: 4 single-line nav links with hover underlines */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-300">
          <button
            onClick={() => {
              soundManager.playClick();
              setActiveView('hub');
            }}
            className={`whitespace-nowrap shrink-0 hover:text-white transition py-1 border-b-2 ${
              activeView === 'hub' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400'
            }`}
          >
            Game Library
          </button>
          <button
            onClick={() => {
              soundManager.playClick();
              setActiveView('simulator');
            }}
            className={`whitespace-nowrap shrink-0 hover:text-white transition py-1 border-b-2 ${
              activeView === 'simulator' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400'
            }`}
          >
            Interactive In-Game HUD
          </button>
          <button
            onClick={() => {
              soundManager.playClick();
              setActiveView('tweaks');
            }}
            className={`whitespace-nowrap shrink-0 hover:text-white transition py-1 border-b-2 ${
              activeView === 'tweaks' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400'
            }`}
          >
            Hardware &amp; Tweaks
          </button>
          <button
            onClick={() => {
              soundManager.playClick();
              setIsPrivilegeModalOpen(true);
            }}
            className="whitespace-nowrap shrink-0 hover:text-cyan-300 text-slate-400 transition py-1 border-b-2 border-transparent flex items-center gap-1.5"
          >
            <ShieldCheck className="h-3.5 w-3.5 text-cyan-400" />
            <span>Root &amp; Shizuku ({privilegeMode.toUpperCase()})</span>
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action + Audio Toggle */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => {
              const muted = soundManager.toggleMute();
              setIsMuted(muted);
            }}
            className="p-2 rounded-lg bg-slate-900 border border-white/10 text-slate-300 hover:text-cyan-300 transition"
            title={isMuted ? 'Nyalakan Audio SFX' : 'Bisukan Suara'}
            aria-label="Toggle Sound Effects"
          >
            {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </button>

          <button
            onClick={() => {
              soundManager.playToggle(!crosshairConfig.enabled);
              setCrosshairConfig((prev) => ({ ...prev, enabled: !prev.enabled }));
            }}
            className={`p-2 rounded-lg border text-xs font-semibold transition ${
              crosshairConfig.enabled
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/60 shadow-sm'
                : 'bg-slate-900 border-white/10 text-slate-400 hover:text-white'
            }`}
            title={crosshairConfig.enabled ? 'Floating Crosshair: Aktif' : 'Floating Crosshair: Mati'}
            aria-label="Toggle Global Crosshair"
          >
            <Crosshair className="h-4 w-4" />
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              setIsExportModalOpen(true);
            }}
            className="px-3.5 py-2 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition shadow-md shadow-cyan-500/20 whitespace-nowrap shrink-0 flex items-center gap-1.5 active:scale-95"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Pasang APK</span>
          </button>
        </div>
      </header>

      {/* MOBILE BOTTOM NAVIGATION ANCHOR (Thumb zone for smartphone viewports) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#07090e]/95 backdrop-blur-md border-t border-white/10 flex items-center justify-around h-16 px-2">
        <button
          onClick={() => {
            soundManager.playClick();
            setActiveView('hub');
          }}
          className={`flex flex-col items-center justify-center w-1/4 h-full ${
            activeView === 'hub' ? 'text-cyan-400' : 'text-slate-400'
          }`}
        >
          <Gamepad2 className="h-5 w-5" />
          <span className="text-[10px] font-medium mt-1">Games</span>
        </button>

        <button
          onClick={() => {
            soundManager.playClick();
            setActiveView('simulator');
          }}
          className={`flex flex-col items-center justify-center w-1/4 h-full ${
            activeView === 'simulator' ? 'text-cyan-400' : 'text-slate-400'
          }`}
        >
          <Play className="h-5 w-5" />
          <span className="text-[10px] font-medium mt-1">HUD Play</span>
        </button>

        <button
          onClick={() => {
            soundManager.playClick();
            setActiveView('tweaks');
          }}
          className={`flex flex-col items-center justify-center w-1/4 h-full ${
            activeView === 'tweaks' ? 'text-cyan-400' : 'text-slate-400'
          }`}
        >
          <Cpu className="h-5 w-5" />
          <span className="text-[10px] font-medium mt-1">Tweaks</span>
        </button>

        <button
          onClick={() => {
            soundManager.playClick();
            setIsPrivilegeModalOpen(true);
          }}
          className="flex flex-col items-center justify-center w-1/4 h-full text-slate-400 hover:text-cyan-300"
        >
          <ShieldCheck className="h-5 w-5" />
          <span className="text-[10px] font-medium mt-1">Shizuku</span>
        </button>
      </div>

      {/* MAIN VIEWPORT CONTENT */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 pb-20 md:pb-8">
        {activeView === 'hub' && (
          <GameLauncherHub
            games={games}
            onLaunchGame={handleLaunchGame}
            onUpdateGame={(updated) =>
              setGames(games.map((g) => (g.id === updated.id ? updated : g)))
            }
            onAddGame={(newG) =>
              setGames([
                ...games,
                { ...newG, id: `game-${Date.now()}` }
              ])
            }
            onDeleteGame={(id) => setGames(games.filter((g) => g.id !== id))}
            privilegeMode={privilegeMode}
            systemTweaks={systemTweaks}
            onUpdateTweaks={handleUpdateTweaks}
            onOpenPrivilegeModal={() => setIsPrivilegeModalOpen(true)}
            onOpenExportModal={() => setIsExportModalOpen(true)}
          />
        )}

        {activeView === 'simulator' && (
          <DeviceSimulatorView
            game={activeGame}
            onExit={() => setActiveView('hub')}
            telemetry={telemetry}
            privilegeMode={privilegeMode}
            systemTweaks={systemTweaks}
            onUpdateTweaks={handleUpdateTweaks}
            crosshairConfig={crosshairConfig}
            onUpdateCrosshair={handleUpdateCrosshair}
            onAddLog={addLog}
          />
        )}

        {activeView === 'tweaks' && (
          <SystemTweaksTab
            tweaks={systemTweaks}
            onUpdateTweaks={handleUpdateTweaks}
            privilegeMode={privilegeMode}
            onAddLog={addLog}
          />
        )}
      </main>

      {/* Global In-Game Overlay Panel for quick access in all tabs */}
      {activeView !== 'simulator' && (
        <InGameOverlayPanel
          isOpen={isGlobalOverlayOpen}
          onToggle={() => setIsGlobalOverlayOpen(!isGlobalOverlayOpen)}
          telemetry={telemetry}
          privilegeMode={privilegeMode}
          systemTweaks={systemTweaks}
          onUpdateTweaks={handleUpdateTweaks}
          crosshairConfig={crosshairConfig}
          onUpdateCrosshair={handleUpdateCrosshair}
          onAddLog={addLog}
          gameTitle={activeGame?.name || 'Aura Gaming Engine'}
        />
      )}

      {/* PRIVILEGE MANAGER MODAL (Root / Shizuku / ADB Terminal) */}
      <PrivilegeManagerModal
        isOpen={isPrivilegeModalOpen}
        onClose={() => setIsPrivilegeModalOpen(false)}
        privilegeMode={privilegeMode}
        onSelectPrivilege={(mode) => setPrivilegeMode(mode)}
        logs={logs}
        onAddLog={addLog}
        systemTweaks={systemTweaks}
      />

      {/* APK INSTALL & SCRIPT EXPORT MODAL */}
      <ApkExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        systemTweaks={systemTweaks}
      />
    </div>
  );
}
