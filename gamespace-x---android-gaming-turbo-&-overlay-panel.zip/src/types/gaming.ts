/**
 * GameSpace X - Core Types
 */

export type PerformanceMode = 'beast' | 'balanced' | 'eco' | 'ultra_touch';

export type PrivilegeMode = 'root' | 'shizuku' | 'standard';

export interface GameItem {
  id: string;
  name: string;
  packageName: string;
  bannerUrl: string;
  category: string;
  genre: string;
  targetFps: 60 | 90 | 120 | 144;
  performanceMode: PerformanceMode;
  resolutionScale: 75 | 85 | 100 | 125;
  msaa4x: boolean;
  touchSamplingRate: 240 | 360 | 480 | 720 | 1000;
  customDns: 'default' | 'cloudflare_gaming' | 'google' | 'quad9';
  playtimeHours: number;
  lastPlayed: string;
}

export interface TelemetryData {
  fps: number;
  targetFps: number;
  frameHistory: number[];
  cpuUsage: number;
  cpuTempC: number;
  cpuFreqGhz: number;
  gpuUsage: number;
  gpuFreqMhz: number;
  ramUsedGb: number;
  ramTotalGb: number;
  pingMs: number;
  jitterMs: number;
  packetLoss: number;
  batteryPct: number;
  isBypassCharging: boolean;
  fanSpeedRpm: number;
}

export type CrosshairStyle = 'red_dot' | 'classic_cross' | 'tactical_circle' | 'chevron' | 'cyber_reticle';

export interface CrosshairConfig {
  enabled: boolean;
  style: CrosshairStyle;
  color: string;
  size: number;
  thickness: number;
  opacity: number;
  position?: { x: number; y: number }; // percentage 0-100 across container
  isLocked?: boolean;
}

export type VoiceChangerPreset = 'off' | 'deep_titan' | 'cyber_cyborg' | 'alien_chipmunk' | 'tactical_radio';

export interface SystemTweakState {
  dndCalls: boolean;
  dndNotifications: boolean;
  lockGestures: boolean;
  lockBrightness: boolean;
  brightnessValue: number;
  bypassCharging: boolean;
  bypassThermal: boolean;
  touchSamplingBoost: boolean;
  samplingRate: 240 | 360 | 480 | 720 | 1000;
  refreshRate: 60 | 90 | 120 | 144;
  gpuRenderer: 'vulkan' | 'opengl' | 'skiavk';
  activeDns: 'default' | 'cloudflare_gaming' | 'google' | 'quad9';
  governor: 'schedutil' | 'performance' | 'powersave' | 'conservative';
  screenResolution: 'native' | '1080p' | '720p' | '2k';
  zramOptimized: boolean;
  framePacingBuffer: boolean;
}

export interface TerminalLog {
  id: string;
  timestamp: string;
  command: string;
  source: 'root' | 'shizuku' | 'kernel' | 'system';
  status: 'success' | 'running' | 'warn';
  output?: string;
}
